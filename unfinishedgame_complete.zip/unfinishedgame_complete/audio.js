/* Fully synthesized audio (WebAudio). No sample files. Created on first user gesture. */
(function (G) {
  'use strict';
  const U = G.util;

  function noiseBuffer(ctx, secs = 2) {
    const b = ctx.createBuffer(1, ctx.sampleRate * secs, ctx.sampleRate), d = b.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    return b;
  }

  G.Audio = {
    ctx: null,
    init() {
      if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return; }
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      const ctx = (this.ctx = new AC());
      const master = (this.master = ctx.createGain());
      master.gain.value = 0.6; master.connect(ctx.destination);
      const noise = (this.noise = noiseBuffer(ctx));
      const loopNoise = (filterType, freq, q, gain) => {
        const s = ctx.createBufferSource(); s.buffer = noise; s.loop = true;
        const f = ctx.createBiquadFilter(); f.type = filterType; f.frequency.value = freq; f.Q.value = q;
        const g = ctx.createGain(); g.gain.value = gain;
        s.connect(f); f.connect(g); g.connect(master); s.start();
        return { f, g };
      };
      // engine: two detuned saws + square sub through a low-pass, plus intake noise
      const eng = (this.eng = { g: ctx.createGain(), f: ctx.createBiquadFilter(), o: [] });
      eng.f.type = 'lowpass'; eng.f.frequency.value = 900; eng.g.gain.value = 0;
      ['sawtooth', 'sawtooth', 'square'].forEach((t, i) => {
        const o = ctx.createOscillator(); o.type = t; o.detune.value = i * 7 - 7;
        const og = ctx.createGain(); og.gain.value = i === 2 ? 0.25 : 0.4;
        o.connect(og); og.connect(eng.f); o.start(); eng.o.push(o);
      });
      eng.f.connect(eng.g); eng.g.connect(master);
      this.intake = loopNoise('bandpass', 1400, 0.7, 0);
      this.wind = loopNoise('lowpass', 500, 0.3, 0);
      this.road = loopNoise('lowpass', 260, 0.4, 0);
      this.skid = loopNoise('bandpass', 2300, 6, 0);
      this.city = loopNoise('lowpass', 180, 0.2, 0.05); // distant city hum
      this.hornG = ctx.createGain(); this.hornG.gain.value = 0; this.hornG.connect(master);
      [415, 523].forEach((fr) => { const o = ctx.createOscillator(); o.type = 'square'; o.frequency.value = fr; const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 1800; o.connect(f); f.connect(this.hornG); o.start(); });
    },
    /** Update looping sounds. s: {rpm 0..1, load 0..1, speed m/s, slip 0..1, driving bool} */
    update(s, dt) {
      if (!this.ctx) return;
      const t = this.ctx.currentTime, k = 0.06;
      const on = s.driving ? 1 : 0;
      const fr = 38 + s.rpm * 190;
      this.eng.o.forEach((o, i) => o.frequency.setTargetAtTime(fr * (i === 2 ? 0.5 : 1), t, k));
      this.eng.f.frequency.setTargetAtTime(400 + s.rpm * 1500 + s.load * 900, t, k);
      this.eng.g.gain.setTargetAtTime(on * (0.1 + 0.16 * s.load + 0.05 * s.rpm), t, k);
      this.intake.g.gain.setTargetAtTime(on * s.load * s.rpm * 0.07, t, k);
      this.wind.g.gain.setTargetAtTime(Math.min(0.22, (s.speed / 70) * (s.speed / 70) * 0.3), t, k);
      this.road.g.gain.setTargetAtTime(on * Math.min(0.12, s.speed / 120), t, k);
      this.skid.f.frequency.setTargetAtTime(1800 + s.speed * 12, t, k);
      this.skid.g.gain.setTargetAtTime(on * U.clamp(s.slip, 0, 1) * 0.09, t, 0.04);
    },
    horn(on) { if (this.ctx) this.hornG.gain.setTargetAtTime(on ? 0.12 : 0, this.ctx.currentTime, 0.015); },
    /** Short noise burst, used for impacts, doors and footsteps. */
    burst(vol = 0.3, freq = 300, dur = 0.18, type = 'lowpass') {
      if (!this.ctx) return;
      const ctx = this.ctx, s = ctx.createBufferSource(); s.buffer = this.noise;
      const f = ctx.createBiquadFilter(); f.type = type; f.frequency.value = freq;
      const g = ctx.createGain(), t = ctx.currentTime;
      g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
      s.connect(f); f.connect(g); g.connect(this.master); s.start(t, Math.random(), dur + 0.05);
    },
    crash(power) { const p = U.clamp(power / 25, 0.1, 1); this.burst(0.7 * p, 900, 0.35); this.burst(0.8 * p, 110, 0.4); },
    door() { this.burst(0.4, 500, 0.12); this.burst(0.3, 120, 0.2); },
    step(run) { this.burst(run ? 0.1 : 0.06, 700, 0.07, 'bandpass'); },
    click() { this.burst(0.12, 3000, 0.04, 'highpass'); },
  };
})(window.Game);
