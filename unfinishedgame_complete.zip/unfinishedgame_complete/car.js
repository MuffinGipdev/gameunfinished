/* Procedural car models. Front is +Z, driver (left-hand drive) sits on local +X.
 * Body silhouettes are extruded from side profiles, then smoothed; wheels, lights and trim are primitives. */
(function (G) {
  'use strict';
  const U = G.util;

  // Side profiles: [z, y] top outline from rear-bottom over the roof line to front-bottom, plus cabin quad.
  // cab = [rearBase, rearRoof, frontRoof, frontBase]
  const LOOK = {
    sports: { yb: 0.16, top: [[-2.22, 0.34], [-2.22, 0.66], [-1.95, 0.84], [-1.55, 0.88], [0.45, 0.84], [1.4, 0.74], [2.0, 0.62], [2.22, 0.46], [2.22, 0.3]],
      cab: [[-1.55, 0.88], [-1.0, 1.15], [-0.05, 1.18], [0.45, 0.85]], spoiler: true, eyeY: 0.96 },
    muscle: { yb: 0.18, top: [[-2.45, 0.38], [-2.45, 0.88], [-2.2, 0.96], [-1.45, 0.96], [0.7, 0.98], [1.4, 1.02], [2.2, 0.96], [2.45, 0.8], [2.45, 0.4]],
      cab: [[-1.4, 0.96], [-0.85, 1.36], [0.15, 1.38], [0.7, 0.99]], spoiler: true, scoop: true, eyeY: 1.12 },
    sedan: { yb: 0.18, top: [[-2.35, 0.38], [-2.35, 0.82], [-2.2, 0.92], [-1.55, 0.93], [0.75, 0.9], [1.3, 0.9], [1.9, 0.82], [2.3, 0.66], [2.35, 0.34]],
      cab: [[-1.55, 0.93], [-1.0, 1.43], [0.2, 1.45], [0.78, 0.91]], eyeY: 1.2 },
    suv: { yb: 0.3, top: [[-2.42, 0.5], [-2.42, 1.12], [-2.3, 1.16], [-2.1, 1.16], [1.0, 1.15], [1.5, 1.12], [2.2, 1.02], [2.42, 0.88], [2.42, 0.5]],
      cab: [[-2.15, 1.16], [-2.1, 1.86], [0.5, 1.88], [1.02, 1.17]], roofRails: true, eyeY: 1.55 },
  };
  G.LOOK = LOOK;

  const shared = {};
  function sharedGeo(key, make) { return shared[key] || (shared[key] = make()); }

  function extrudeProfile(pts, width, bevel = 0.06) {
    const shape = new THREE.Shape(pts.map((p) => new THREE.Vector2(p[0], p[1])));
    const depth = Math.max(0.05, width - 2 * bevel);
    const g = new THREE.ExtrudeGeometry(shape, { depth, bevelEnabled: true, bevelThickness: bevel, bevelSize: bevel * 0.8, bevelSegments: 3, curveSegments: 4 });
    g.rotateY(-Math.PI / 2); // profile x -> +Z (front), extrusion -> X
    g.translate(depth / 2, 0, 0);
    return U.smoothNormals(g, 50);
  }

  function bodyOutline(spec, look) {
    const zf = look.top[look.top.length - 1][0], zr = look.top[0][0], r = spec.wr + 0.07, yb = look.yb;
    const pts = look.top.map((p) => p.slice());
    const arch = (zc) => { const a = []; for (let i = 0; i <= 8; i++) { const t = (i / 8) * Math.PI; a.push([zc - Math.cos(t) * r, yb + spec.wr - 0.02 + Math.sin(t) * r * 0.82]); } return a; };
    // bottom edge runs front -> rear; arches are cut where the wheels sit
    pts.push([zf, yb]);
    pts.push(...arch(spec.wb / 2).reverse().map((p) => [p[0], p[1]]));
    pts.push(...arch(-spec.wb / 2).reverse());
    pts.push([zr, yb]);
    return U.chaikin(pts, 1);
  }

  function makeMats(color) {
    const paint = G.reg(new THREE.MeshPhysicalMaterial({ color, metalness: 0.55, roughness: 0.32, clearcoat: 1, clearcoatRoughness: 0.06 }), 1.1);
    const glass = G.reg(new THREE.MeshPhysicalMaterial({ color: 0x0c1824, metalness: 0.1, roughness: 0.04, transparent: true, opacity: 0.55 }), 1.6);
    const black = G.reg(new THREE.MeshStandardMaterial({ color: 0x0b0c0f, roughness: 0.55, metalness: 0.3 }));
    const rubber = new THREE.MeshStandardMaterial({ color: 0x0a0a0b, roughness: 0.92, metalness: 0 });
    const chrome = G.reg(new THREE.MeshStandardMaterial({ color: 0xd8dde6, roughness: 0.14, metalness: 1 }), 1.3);
    return { paint, glass, black, rubber, chrome };
  }

  /** Build one car. opts: { color, plate }. Returns a Group with userData.car controls. */
  G.buildCar = function (spec, opts = {}) {
    const look = LOOK[spec.id], color = new THREE.Color(opts.color || '#d7263d');
    const M = makeMats(color);
    const root = new THREE.Group(), body = new THREE.Group();
    root.add(body);
    const add = (mesh, parent = body, shadow = true) => { mesh.castShadow = shadow; parent.add(mesh); return mesh; };
    const W = spec.W, L = spec.L;

    // --- shell ---
    const outline = bodyOutline(spec, look);
    add(new THREE.Mesh(sharedGeo('body' + spec.id, () => extrudeProfile(outline, W)), M.paint));
    const [rb, rr, fr, fb] = look.cab, gw = W * 0.86;
    add(new THREE.Mesh(sharedGeo('cab' + spec.id, () => extrudeProfile([rb, rr, fr, fb].map((p) => [p[0], p[1] - 0.02]), gw, 0.03)), M.glass), body, false);
    // painted roof panel and pillars
    const roofGeo = sharedGeo('roof' + spec.id, () => extrudeProfile([[rr[0] - 0.05, rr[1] - 0.04], [rr[0] - 0.02, rr[1] + 0.02], [fr[0] + 0.02, fr[1] + 0.02], [fr[0] + 0.05, fr[1] - 0.04]], gw * 1.02, 0.025));
    add(new THREE.Mesh(roofGeo, M.paint));
    const pillar = (a, b, t) => new THREE.Shape([new THREE.Vector2(a[0], a[1]), new THREE.Vector2(b[0], b[1]), new THREE.Vector2(b[0] + t * 0.8, b[1] - 0.02), new THREE.Vector2(a[0] + t, a[1] + 0.02)]);
    [[fb, fr, 0.09], [rb, rr, -0.09]].forEach(([a, b, t]) => [-1, 1].forEach((s) => {
      const g = sharedGeo('pil' + spec.id + a[0] + s, () => { const ge = new THREE.ExtrudeGeometry(pillar(a, b, t), { depth: 0.07, bevelEnabled: false }); ge.rotateY(-Math.PI / 2); return ge; });
      const m = add(new THREE.Mesh(g, M.paint)); m.position.x = s * (gw / 2 - 0.02) + 0.035;
    }));
    // dark under-tray fills the wheel-arch tunnels so you never see through the car
    const tray = add(new THREE.Mesh(new THREE.BoxGeometry(spec.track - 0.55, 0.3, L - 0.3), M.black), body, false);
    tray.position.set(0, look.yb + 0.2, 0);
    const wellMat = new THREE.MeshStandardMaterial({ color: 0x050506, roughness: 0.9, side: THREE.BackSide });
    const wellGeo = sharedGeo('well' + spec.id, () => new THREE.CylinderGeometry(spec.wr + 0.06, spec.wr + 0.06, 0.34, 20, 1, true).rotateZ(Math.PI / 2));
    [-1, 1].forEach((s) => [-1, 1].forEach((f) => { // wheel wells
      const well = add(new THREE.Mesh(wellGeo, wellMat), body, false);
      well.position.set(s * (spec.track / 2 - 0.02), look.yb + spec.wr - 0.02, f * spec.wb / 2);
    }));

    // --- trim: grille, splitter, diffuser, door lines, handles, mirrors, plates, exhaust ---
    const zF = look.top[look.top.length - 1][0], zR = look.top[0][0], hy = look.top[look.top.length - 2][1];
    const trim = (w, h, d, x, y, z, mat = M.black) => { const m = add(new THREE.Mesh(sharedGeo(`t${w}${h}${d}`, () => new THREE.BoxGeometry(w, h, d)), mat), body, false); m.position.set(x, y, z); return m; };
    trim(W * 0.62, 0.16, 0.06, 0, hy - 0.2, zF + 0.04); // grille
    trim(W * 0.9, 0.05, 0.3, 0, look.yb + 0.1, zF - 0.05); // splitter
    trim(W * 0.8, 0.14, 0.12, 0, look.yb + 0.16, zR + 0.04); // diffuser
    const plateTex = G.Tex.plate(opts.plate || 'NV-' + Math.floor(100 + Math.random() * 900));
    const plate = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.25), new THREE.MeshBasicMaterial({ map: plateTex }));
    plate.position.set(0, look.yb + 0.34, zR - 0.075); plate.rotation.y = Math.PI; body.add(plate);
    const plateF = plate.clone(); plateF.position.set(0, look.yb + 0.3, zF + 0.065); plateF.rotation.y = 0; body.add(plateF);
    [-1, 1].forEach((s) => {
      const x = s * (W / 2 + 0.003), by = look.cab[0][1];
      [rb[0] + 0.55, (rb[0] + fb[0]) / 2 - 0.05, fb[0] - 0.12].forEach((z) => trim(0.012, by - look.yb - 0.3, 0.012, x, (by + look.yb) / 2 + 0.05, z)); // door cuts
      trim(0.05, 0.03, 0.18, s * (W / 2 + 0.01), by - 0.1, (rb[0] + fb[0]) / 2 - 0.35, M.paint); // handle
      const mir = trim(0.14, 0.1, 0.1, s * (W / 2 + 0.1), by + 0.1, fb[0] - 0.05, M.paint); mir.rotation.y = s * 0.2; // mirror
      trim(0.02, 0.1, 0.08, s * (W / 2 + 0.01), look.yb + 0.28, 0, M.black); trim(0.1, 0.1, 0.5, s * (W * 0.3), look.yb + 0.17, zR + 0.05, M.chrome); // skirt + exhaust
    });
    if (look.spoiler) { trim(W * 0.78, 0.04, 0.34, 0, look.top[1][1] + 0.12, zR + 0.38, M.paint); [-1, 1].forEach((s) => trim(0.04, 0.14, 0.2, s * W * 0.3, look.top[1][1] + 0.04, zR + 0.4, M.black)); }
    if (look.scoop) trim(0.5, 0.1, 0.8, 0, look.top[5][1] + 0.05, 1.5, M.black);
    if (look.roofRails) [-1, 1].forEach((s) => trim(0.05, 0.05, fr[0] - rr[0] - 0.3, s * W * 0.34, rr[1] + 0.07, (fr[0] + rr[0]) / 2, M.chrome));

    // --- wheels ---
    const wheels = [];
    const tireGeo = sharedGeo('tire' + spec.id, () => new THREE.CylinderGeometry(spec.wr, spec.wr, 0.27, 28).rotateZ(Math.PI / 2));
    const rimGeo = sharedGeo('rim' + spec.id, () => new THREE.CylinderGeometry(spec.wr * 0.68, spec.wr * 0.68, 0.28, 24).rotateZ(Math.PI / 2));
    const spokeGeo = sharedGeo('spoke' + spec.id, () => new THREE.BoxGeometry(0.29, spec.wr * 1.2, 0.045));
    const discGeo = sharedGeo('disc' + spec.id, () => new THREE.CylinderGeometry(spec.wr * 0.5, spec.wr * 0.5, 0.3, 20).rotateZ(Math.PI / 2));
    [[1, 1], [-1, 1], [1, -1], [-1, -1]].forEach(([s, f]) => {
      const pivot = new THREE.Group(), spin = new THREE.Group();
      pivot.position.set(s * spec.track / 2, spec.wr, f * spec.wb / 2);
      add(new THREE.Mesh(tireGeo, M.rubber), spin);
      add(new THREE.Mesh(rimGeo, M.chrome), spin, false);
      add(new THREE.Mesh(discGeo, M.black), spin, false);
      for (let k = 0; k < 5; k++) { const sp = add(new THREE.Mesh(spokeGeo, M.chrome), spin, false); sp.rotation.x = (k / 5) * Math.PI; }
      pivot.add(spin); root.add(pivot);
      wheels.push({ pivot, spin, front: f > 0 });
    });

    // --- lights (emissive meshes; materials unique per car so each state is independent) ---
    const mk = (c, k = 0) => new THREE.MeshStandardMaterial({ color: 0x15151a, emissive: c, emissiveIntensity: k, roughness: 0.25 });
    const L_ = { head: mk(0xfff2d8), tail: mk(0xff1010), brake: mk(0xff2a1a), rev: mk(0xffffff), tl: mk(0xffa010), tr: mk(0xffa010), tfl: mk(0xffa010), tfr: mk(0xffa010) };
    const lamp = (mat, w, h, d, x, y, z) => { const m = new THREE.Mesh(sharedGeo(`l${w}${h}${d}`, () => new THREE.BoxGeometry(w, h, d)), mat); m.position.set(x, y, z); body.add(m); return m; };
    const hw = W / 2 - 0.3;
    [-1, 1].forEach((s) => {
      lamp(L_.head, 0.34, 0.09, 0.06, s * hw, hy - 0.08, zF - 0.01).rotation.y = -s * 0.15;
      lamp(L_.tail, 0.42, 0.07, 0.05, s * hw, look.top[1][1] - 0.1, zR + 0.01);
      lamp(L_.brake, 0.42, 0.05, 0.05, s * hw, look.top[1][1] - 0.18, zR + 0.012);
      lamp(L_.rev, 0.12, 0.06, 0.05, s * (hw - 0.45), look.yb + 0.34, zR + 0.01);
      lamp(s > 0 ? L_.tl : L_.tr, 0.16, 0.06, 0.05, s * (hw + 0.3), look.top[1][1] - 0.1, zR + 0.008);
      lamp(s > 0 ? L_.tfl : L_.tfr, 0.16, 0.06, 0.05, s * (hw + 0.3), hy - 0.08, zF - 0.008);
    });
    // ground contact shadow blob
    const blob = new THREE.Mesh(new THREE.PlaneGeometry(W * 1.5, L * 1.2).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ map: G.tex.glow, color: 0x000000, transparent: true, opacity: 0.55, depthWrite: false }));
    blob.position.y = 0.03; root.add(blob);

    // --- controller ---
    const car = {
      spec, look, root, body, wheels, mats: M, lights: L_, spots: null, blink: 0, headMode: 0, cockpit: null, blob,
      setColor(hex) { M.paint.color.set(hex); },
      /** Headlight spot lights (player-driven car only). */
      enableSpots(on) {
        if (on && !car.spots) {
          car.spots = [-1, 1].map((s) => {
            const sp = new THREE.SpotLight(0xfff0d8, 0, 110, 0.5, 0.55, 2);
            sp.position.set(s * hw, hy - 0.08, zF - 0.1); const t = new THREE.Object3D(); t.position.set(s * hw * 0.6, hy - 1.6, zF + 18);
            body.add(sp, t); sp.target = t; return sp;
          });
        }
        if (car.spots) car.spots.forEach((sp) => (sp.visible = on));
      },
      /** state: {head 0|1|2, brake, reverse, left, right, dt} */
      setLights(st, dt) {
        car.blink += dt; const on = Math.floor(car.blink * 2.6) % 2 === 0;
        const h = st.head, hk = h === 0 ? 0 : h === 1 ? 1.6 : 3;
        L_.head.emissiveIntensity = hk; L_.tail.emissiveIntensity = h ? 1.1 : 0.15;
        L_.brake.emissiveIntensity = st.brake ? 3.2 : 0; L_.rev.emissiveIntensity = st.reverse ? 3 : 0;
        const tl = st.left && on ? 3 : 0, tr = st.right && on ? 3 : 0;
        L_.tl.emissiveIntensity = L_.tfl.emissiveIntensity = tl; L_.tr.emissiveIntensity = L_.tfr.emissiveIntensity = tr;
        if (car.spots) car.spots.forEach((sp, i) => { sp.intensity = h === 0 ? 0 : h === 1 ? 2800 : 6500; sp.angle = h === 2 ? 0.42 : 0.55; });
      },
      dispose() { root.parent && root.parent.remove(root); },
    };
    root.userData.car = car;
    return car;
  };
})(window.Game);
