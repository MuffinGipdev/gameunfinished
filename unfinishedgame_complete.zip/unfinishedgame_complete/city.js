/* Procedural city: PBR asphalt roads with markings, sidewalks, detailed towers with lit windows,
 * neon signage, street lamps, a fountain plaza, a waterfront promenade, colliders and a minimap. */
(function (G) {
  'use strict';
  const U = G.util, C = G.C, P = G.proc;

  /** Spatial hash of axis-aligned boxes for car / pedestrian collision. */
  G.Collide = (() => {
    const CELL = 40, map = new Map(), key = (i, j) => i * 100003 + j;
    return {
      add(x, z, hx, hz) {
        const b = { x, z, hx, hz };
        for (let i = Math.floor((x - hx) / CELL); i <= Math.floor((x + hx) / CELL); i++)
          for (let j = Math.floor((z - hz) / CELL); j <= Math.floor((z + hz) / CELL); j++) {
            const k = key(i, j);
            if (!map.has(k)) map.set(k, []);
            map.get(k).push(b);
          }
      },
      /** Push a circle out of boxes. Returns {x,z,hit,nx,nz,depth}. */
      resolve(px, pz, r) {
        let hit = false, nx = 0, nz = 0, depth = 0;
        const ci = Math.floor(px / CELL), cj = Math.floor(pz / CELL);
        for (let i = ci - 1; i <= ci + 1; i++)
          for (let j = cj - 1; j <= cj + 1; j++) {
            const l = map.get(key(i, j));
            if (!l) continue;
            for (const b of l) {
              const qx = U.clamp(px, b.x - b.hx, b.x + b.hx), qz = U.clamp(pz, b.z - b.hz, b.z + b.hz);
              let dx = px - qx, dz = pz - qz, d2 = dx * dx + dz * dz, d;
              if (d2 >= r * r) continue;
              if (d2 < 1e-8) {
                const ox = b.hx - Math.abs(px - b.x), oz = b.hz - Math.abs(pz - b.z);
                if (ox < oz) { dx = Math.sign(px - b.x) || 1; dz = 0; d = ox + r; } else { dz = Math.sign(pz - b.z) || 1; dx = 0; d = oz + r; }
              } else { const dist = Math.sqrt(d2); dx /= dist; dz /= dist; d = r - dist; }
              px += dx * d; pz += dz * d; nx += dx; nz += dz; hit = true; depth = Math.max(depth, d);
            }
          }
        const l = Math.hypot(nx, nz) || 1;
        return { x: px, z: pz, hit, nx: nx / l, nz: nz / l, depth };
      },
      inside(px, pz, m = 0) {
        const l = map.get(key(Math.floor(px / CELL), Math.floor(pz / CELL)));
        if (l) for (const b of l) if (Math.abs(px - b.x) < b.hx + m && Math.abs(pz - b.z) < b.hz + m) return true;
        return false;
      },
    };
  })();

  function roadQuad(axis, c, a, b, h) {
    // axis 'x': road runs along X at z=c; axis 'z': runs along Z at x=c. a..b = extent along the road.
    const w = C.ROAD / 2, p = [], uv = [];
    const A = axis === 'x' ? [a, c - w] : [c - w, a], B = axis === 'x' ? [b, c - w] : [c + w, a];
    const Cc = axis === 'x' ? [a, c + w] : [c - w, b], D = axis === 'x' ? [b, c + w] : [c + w, b];
    [A, B, Cc, D].forEach((q) => {
      p.push(q[0], 0, q[1]);
      uv.push(...(axis === 'x' ? [(q[1] - (c - w)) / C.ROAD, q[0] / 16] : [(q[0] - (c - w)) / C.ROAD, q[1] / 16]));
    });
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(p), 3));
    g.setAttribute('normal', new THREE.BufferAttribute(new Float32Array([0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0]), 3));
    g.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(uv), 2));
    g.setIndex([0, 2, 1, 1, 2, 3]);
    return g;
  }

  G.buildCity = function (scene) {
    const T = G.tex, rand = U.rng(2024), col = (h) => new THREE.Color(h);
    const city = { sources: [], glows: [], blocks: [], showroom: [] };
    G.sources = city.sources;
    const ext = C.HALF + 60, zEnd = C.BAY_Z - 6;

    // ---------- materials ----------
    const roadMat = G.reg(new THREE.MeshStandardMaterial({ map: T.asphalt.map, roughnessMap: T.asphalt.rough, normalMap: T.asphalt.normal, normalScale: new THREE.Vector2(1.2, 1.2), roughness: 1, metalness: 0 }));
    const roadMat2 = roadMat.clone(); roadMat2.polygonOffset = true; roadMat2.polygonOffsetFactor = roadMat2.polygonOffsetUnits = -1; G.reg(roadMat2);
    const walkMat = G.reg(new THREE.MeshStandardMaterial({ map: T.sidewalk.map, roughnessMap: T.sidewalk.rough, normalMap: T.sidewalk.normal, roughness: 1, metalness: 0 }));
    const markMat = G.reg(new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.5, metalness: 0, polygonOffset: true, polygonOffsetFactor: -3, polygonOffsetUnits: -3 }));
    const cityMat = (city.mat = G.reg(new THREE.MeshStandardMaterial({ map: T.facade.map, roughnessMap: T.facade.rough, emissiveMap: T.facade.emissive, emissive: 0xffffff, emissiveIntensity: 1.2, vertexColors: true, roughness: 1, metalness: 0.15 }), 0.8));
    const neonMat = new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false });

    // ---------- roads ----------
    C.lines.forEach((c) => {
      const h = new THREE.Mesh(roadQuad('x', c, -ext, ext), roadMat); h.position.y = 0.02; h.receiveShadow = true; scene.add(h);
      const v = new THREE.Mesh(roadQuad('z', c, -ext, zEnd), roadMat2); v.position.y = 0.021; v.receiveShadow = true; scene.add(v);
    });

    // ---------- markings (one instanced mesh) ----------
    const inst = [], yel = col(0xf2c230), wht = col(0xe9e9e1);
    const box = (x, z, sx, sz, c) => inst.push({ x, z, sx, sz, c });
    const spans = [];
    for (let k = 0; k < C.GRID; k++) spans.push([C.lines[k] + C.ROAD / 2 + 5.5, C.lines[k + 1] - C.ROAD / 2 - 5.5]);
    C.lines.forEach((c) => spans.forEach(([a, b]) => {
      const len = b - a, mid = (a + b) / 2;
      [[0.18, yel], [-0.18, yel]].forEach(([o, cc]) => { box(mid, c + o, len, 0.12, cc); box(c + o, mid, 0.12, len, cc); });
      [-7.4, 7.4].forEach((o) => { box(mid, c + o, len, 0.16, wht); box(c + o, mid, 0.16, len, wht); });
      for (let p = a + 3; p < b - 2; p += 9) [-3.7, 3.7].forEach((o) => { box(p + 1.5, c + o, 3, 0.14, wht); box(c + o, p + 1.5, 0.14, 3, wht); });
    }));
    C.lines.forEach((xi) => C.lines.forEach((zj) => {
      const d = C.ROAD / 2 + 2.6;
      for (let s = -6.3; s <= 6.4; s += 1.4) [-1, 1].forEach((q) => { box(xi + q * d, zj + s, 3, 0.7, wht); box(xi + s, zj + q * d, 0.7, 3, wht); });
    }));
    {
      const im = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 0.02, 1), markMat, inst.length);
      inst.forEach((m, i) => { im.setMatrixAt(i, U.mat(m.x, 0.04, m.z, 0, m.sx, 1, m.sz)); im.setColorAt(i, m.c); });
      im.frustumCulled = false; im.receiveShadow = true; scene.add(im);
    }

    // ---------- merged static geometry (sidewalk slabs, buildings, trees) ----------
    const slabItems = [], bld = [], neon = [];
    const plazaI = (C.GRID - 1) / 2;
    const tints = [[1, 0.95, 0.9], [0.8, 0.86, 1], [1.1, 1.05, 0.95], [0.9, 0.95, 0.9], [1.25, 1.1, 1], [0.75, 0.8, 0.92]];
    const CONST_UV = [0.012, 0.004];

    function boxGeo(w, h, d, tint, off, plain) {
      const g = new THREE.BoxGeometry(w, h, d), uv = g.attributes.uv, n = uv.count, colr = new Float32Array(n * 3);
      for (let i = 0; i < n; i++) {
        const face = Math.floor(i / 4);
        if (plain || face === 2 || face === 3) { uv.setXY(i, CONST_UV[0], CONST_UV[1]); colr.set(plain ? tint : [0.45, 0.45, 0.5], i * 3); continue; }
        const fw = face < 2 ? d : w;
        uv.setXY(i, uv.getX(i) * (fw / 12) + off[0], uv.getY(i) * (h / 14.4) + off[1]);
        colr.set(tint, i * 3);
      }
      g.setAttribute('color', new THREE.BufferAttribute(colr, 3));
      return g;
    }
    function addBox(cx, y0, cz, w, h, d, tint, off) { bld.push({ g: boxGeo(w, h, d, tint, off), m: U.mat(cx, y0 + h / 2, cz) }); }
    function flat(cx, y, cz, w, h, d, c) { // untextured prop in the static mesh
      bld.push({ g: boxGeo(w, h, d, [c.r, c.g, c.b], [0, 0], true), m: U.mat(cx, y + h / 2, cz) });
    }
    const addNeon = (g, m, c) => neon.push({ g, m, c });
    const unit = new THREE.BoxGeometry(1, 1, 1);

    const signWords = ['NOODLES', 'HOTEL', 'BAR', '24H', 'ARCADE', 'PIZZA', 'RAMEN', 'CLUB', 'NEON', 'KARAOKE', 'TAXI', 'CAFE', 'TECH', 'SUSHI', 'VINYL'];
    const signMeshes = [];

    for (let bi = 0; bi < C.GRID; bi++)
      for (let bj = 0; bj < C.GRID; bj++) {
        const bx = C.centers[bi], bz = C.centers[bj], isPlaza = bi === plazaI && bj === plazaI;
        const slab = new THREE.BoxGeometry(C.BLOCK, C.CURB, C.BLOCK), uv = slab.attributes.uv;
        for (let i = 0; i < uv.count; i++) { const f = Math.floor(i / 4), side = f < 2 || f > 3; uv.setXY(i, uv.getX(i) * (C.BLOCK / 4), uv.getY(i) * (side ? C.CURB / 4 : C.BLOCK / 4)); }
        slabItems.push({ g: slab, m: U.mat(bx, C.CURB / 2, bz) });
        city.blocks.push({ x: bx, z: bz });
        if (isPlaza) continue;

        if (rand() < 0.09) { // park block
          const lawn = new THREE.Mesh(new THREE.PlaneGeometry(C.BLOCK - 8, C.BLOCK - 8).rotateX(-Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0x16311c, roughness: 1 }));
          lawn.position.set(bx, C.CURB + 0.01, bz); lawn.receiveShadow = true; scene.add(lawn);
          for (let t = 0; t < 22; t++) {
            const tx = bx + (rand() - 0.5) * (C.BLOCK - 14), tz = bz + (rand() - 0.5) * (C.BLOCK - 14), s = 0.8 + rand() * 0.7;
            flat(tx, C.CURB, tz, 0.5 * s, 3.2 * s, 0.5 * s, col(0x4a3524));
            const f = new THREE.IcosahedronGeometry(2.4 * s, 1), a = new Float32Array(f.attributes.position.count * 3), cc = col(0x2f6b34).multiplyScalar(2.4);
            for (let i = 0; i < a.length; i += 3) { a[i] = cc.r; a[i + 1] = cc.g * (0.8 + rand() * 0.4); a[i + 2] = cc.b; }
            f.setAttribute('color', new THREE.BufferAttribute(a, 3));
            const fu = f.attributes.uv; for (let i = 0; i < fu.count; i++) fu.setXY(i, CONST_UV[0], CONST_UV[1]);
            bld.push({ g: f, m: U.mat(tx, C.CURB + 3.6 * s, tz, 0, 1, 0.85, 1) });
          }
          continue;
        }

        const inner = C.BLOCK - 2 * C.SIDEWALK, pat = rand(), lots = [];
        if (pat < 0.35) lots.push([0, 0, inner, inner]);
        else if (pat < 0.65) { const h = inner / 2 - 1; if (rand() < 0.5) lots.push([-inner / 4, 0, h, inner], [inner / 4, 0, h, inner]); else lots.push([0, -inner / 4, inner, h], [0, inner / 4, inner, h]); }
        else { const h = inner / 2 - 1, o = inner / 4; lots.push([-o, -o, h, h], [o, -o, h, h], [-o, o, h, h], [o, o, h, h]); }

        for (const [ox, oz, lw, ld] of lots) {
          const w = lw - 1 - rand() * 3, d = ld - 1 - rand() * 3, cx = bx + ox, cz = bz + oz;
          const central = Math.exp(-Math.hypot(bx, bz) / 260);
          let h = 14 + rand() * 24 + central * rand() * 85;
          const tint = U.pick(rand, tints).map((v) => v * (0.9 + rand() * 0.5)), off = [Math.floor(rand() * 4) / 4, Math.floor(rand() * 4) / 4];
          addBox(cx, C.CURB, cz, w, h, d, tint, off);
          G.Collide.add(cx, cz, w / 2, d / 2);
          let topY = C.CURB + h, tw = w, td = d;
          if (h > 38 && rand() < 0.6) { tw = w * 0.66; td = d * 0.66; const h2 = h * (0.2 + rand() * 0.25); addBox(cx, topY, cz, tw, h2, td, tint, off); topY += h2; }
          for (let k = 0; k < 2 + Math.floor(rand() * 3); k++) // rooftop plant
            flat(cx + (rand() - 0.5) * (tw - 4), topY, cz + (rand() - 0.5) * (td - 4), 1.5 + rand() * 2, 1 + rand() * 1.2, 1.5 + rand() * 2, col(0x55585e).multiplyScalar(2));
          if (rand() < 0.5) flat(cx + tw * 0.25, topY, cz - td * 0.25, 0.14, 6 + rand() * 8, 0.14, col(0x888888).multiplyScalar(2)); // antenna
          if (h > 55) addNeon(unit, U.mat(cx + tw / 2 - 0.3, topY + 5, cz + td / 2 - 0.3, 0, 0.5, 0.5, 0.5), col(0xff2a2a)); // aircraft light
          // neon trim band and sign facing the nearest street
          const zf = rand() < 0.5 ? 1 : -1, nc = col(U.pick(rand, G.NEON));
          addNeon(unit, U.mat(cx, C.CURB + 5.6, cz + zf * (d / 2 + 0.08), 0, w * 0.96, 0.22, 0.2), nc);
          if (h > 50) [[1, 1], [-1, -1]].forEach(([a, b]) => addNeon(unit, U.mat(cx + a * w / 2, C.CURB + h * 0.5, cz + b * d / 2, 0, 0.35, h * 0.85, 0.35), col(U.pick(rand, G.NEON))));
          if (rand() < 0.3 && h > 16) {
            const word = U.pick(rand, signWords), sc = U.pick(rand, G.NEON), y = 8 + rand() * 8, sz = 5.5 + rand() * 3;
            const m = new THREE.Mesh(new THREE.PlaneGeometry(sz, sz * 0.31), new THREE.MeshBasicMaterial({ map: G.Tex.sign(word, sc), toneMapped: false, side: THREE.DoubleSide }));
            m.position.set(cx + (rand() - 0.5) * (w - sz), y, cz + zf * (d / 2 + 0.25)); m.rotation.y = zf > 0 ? 0 : Math.PI; scene.add(m);
            const gl = new THREE.Sprite(new THREE.SpriteMaterial({ map: T.glow, color: sc, blending: THREE.AdditiveBlending, transparent: true, depthWrite: false, opacity: 0.6 }));
            gl.position.set(m.position.x, y, m.position.z + zf * 0.5); gl.scale.set(sz * 2.1, sz * 1.0, 1); scene.add(gl); city.glows.push(gl);
            city.sources.push({ x: m.position.x, y, z: m.position.z + zf * 3, color: sc, i: 380 });
          }
        }
      }

    // ---------- lamps ----------
    const lampItems = [], lampPos = [], lampCol = [col(0xffd9a0), col(0xffc890), col(0xc7e0ff)];
    const poleG = new THREE.CylinderGeometry(0.09, 0.13, 7.5, 6);
    function lamp(x, z, dx, dz) { // dx,dz: unit vector pointing toward the road
      const c = lampCol[Math.floor(rand() * 2.99)];
      lampItems.push({ g: poleG, m: U.mat(x, 3.75 + C.CURB, z), c: col(0x2a2d33) });
      lampItems.push({ g: unit, m: U.mat(x + dx * 0.8, 7.5 + C.CURB, z + dz * 0.8, 0, dx ? 1.7 : 0.1, 0.1, dz ? 1.7 : 0.1), c: col(0x2a2d33) });
      addNeon(unit, U.mat(x + dx * 1.5, 7.38 + C.CURB, z + dz * 1.5, 0, 0.7, 0.14, 0.7), c);
      lampPos.push([x + dx * 3.2, z + dz * 3.2]);
      city.sources.push({ x: x + dx * 1.5, y: 7.2, z: z + dz * 1.5, color: c.getHex(), i: 520 });
    }
    C.lines.forEach((c) => spans.forEach(([a, b]) => {
      for (let p = a + 2; p < b; p += 27) [-1, 1].forEach((s) => {
        const o = s * (C.ROAD / 2 + 1.3);
        lamp(p, c + o, 0, -s); lamp(c + o, p, -s, 0);
      });
    }));

    // ---------- plaza: fountain, neon ring, stone floor ----------
    const rim = new THREE.Mesh(new THREE.CylinderGeometry(8.2, 8.4, 0.9, 48), new THREE.MeshStandardMaterial({ color: 0x555a63, roughness: 0.8 }));
    rim.position.set(0, C.CURB + 0.45, 0); rim.castShadow = rim.receiveShadow = true; scene.add(rim);
    const pool = new THREE.Mesh(new THREE.CircleGeometry(7.4, 48).rotateX(-Math.PI / 2), G.waterMat); pool.position.set(0, C.CURB + 0.86, 0); scene.add(pool);
    const jet = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.6, 3.2, 12), new THREE.MeshStandardMaterial({ color: 0x8a909a, roughness: 0.4, metalness: 0.8 }));
    jet.position.set(0, C.CURB + 2.2, 0); jet.castShadow = true; scene.add(jet);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(8.35, 0.09, 8, 64).rotateX(Math.PI / 2), new THREE.MeshBasicMaterial({ color: col(0x25efff), toneMapped: false }));
    ring.position.set(0, C.CURB + 0.95, 0); scene.add(ring);
    G.Collide.add(0, 0, 8.4, 8.4);
    city.sources.push({ x: 0, y: 3, z: 0, color: 0x25efff, i: 500 });
    [-1, 1].forEach((a) => [-1, 1].forEach((b) => { // corner neon pylons
      const px = a * 26, pz = b * 26; flat(px, C.CURB, pz, 0.6, 7, 0.6, col(0x30343c));
      const nc = col(a * b > 0 ? 0xff3bd2 : 0x25efff); addNeon(unit, U.mat(px, C.CURB + 7.3, pz, 0, 1.1, 0.5, 1.1), nc);
      city.sources.push({ x: px, y: 7, z: pz, color: nc.getHex(), i: 350 });
    }));
    [-21, -7, 7, 21].forEach((x, i) => city.showroom.push({ x, z: 22, h: 0, slot: i }));

    // ---------- waterfront promenade ----------
    const prom = new THREE.Mesh(new THREE.PlaneGeometry(2 * (C.HALF + 60), C.BAY_Z - C.HALF - C.ROAD / 2 - 2).rotateX(-Math.PI / 2), walkMat.clone());
    const pu = prom.geometry.attributes.uv; for (let i = 0; i < pu.count; i++) pu.setXY(i, pu.getX(i) * 210, pu.getY(i) * 12);
    prom.position.set(0, 0.01, (C.BAY_Z + C.HALF + C.ROAD / 2 + 2) / 2); prom.receiveShadow = true; G.reg(prom.material); scene.add(prom);
    addNeon(unit, U.mat(0, 0.5, C.BAY_Z - 0.6, 0, 2 * (C.HALF + 60), 0.12, 0.12), col(0x25efff));
    for (let x = -C.HALF - 40; x <= C.HALF + 40; x += 30) { lamp(x, C.BAY_Z - 3, 0, 1); }

    // ---------- build merged meshes ----------
    const mk = (items, mat, shadows) => {
      const m = new THREE.Mesh(U.merge(items), mat); m.castShadow = shadows; m.receiveShadow = shadows; m.frustumCulled = false; scene.add(m); return m;
    };
    const slabs = mk(slabItems, walkMat, true); slabs.castShadow = false;
    mk(bld, cityMat, true);
    mk(lampItems.map((l) => ({ g: l.g, m: l.m, c: l.c })), new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.6, metalness: 0.7 }), true);
    mk(neon, neonMat, false).castShadow = false;

    // glow pools on the asphalt under every lamp
    const decal = new THREE.InstancedMesh(new THREE.PlaneGeometry(16, 16).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ map: T.glow, color: 0xffb870, transparent: true, opacity: 0.5, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false }), lampPos.length);
    lampPos.forEach((p, i) => decal.setMatrixAt(i, U.mat(p[0], 0.05, p[1])));
    decal.frustumCulled = false; scene.add(decal); city.decal = decal;

    // ---------- minimap texture ----------
    const S = 1024, span = 2 * ext, k = S / span, mm = P.canvas(S, S), g = mm.g;
    const X = (x) => (x + ext) * k, Z = (z) => (z + ext) * k;
    g.fillStyle = '#070b14'; g.fillRect(0, 0, S, S);
    g.fillStyle = '#10243a'; g.fillRect(0, Z(C.BAY_Z), S, S);
    g.fillStyle = '#1b2234'; city.blocks.forEach((b) => g.fillRect(X(b.x - C.BLOCK / 2), Z(b.z - C.BLOCK / 2), C.BLOCK * k, C.BLOCK * k));
    g.fillStyle = '#2f3a52';
    C.lines.forEach((c) => { g.fillRect(0, Z(c - C.ROAD / 2), S, C.ROAD * k); g.fillRect(X(c - C.ROAD / 2), 0, C.ROAD * k, Z(zEnd)); });
    city.minimap = { canvas: mm.c, ext, k };
    return city;
  };
})(window.Game);
