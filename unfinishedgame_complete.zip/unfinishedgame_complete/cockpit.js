/* Interior for a car (car-local space: front +Z, driver on +X). Full version has a live gauge cluster
 * (canvas texture), infotainment screen and a steering wheel that turns with the front wheels. */
(function (G) {
  'use strict';
  const U = G.util, P = G.proc;

  function dialBackground(spec) {
    const { c, g } = P.canvas(512, 200);
    g.fillStyle = '#04070c'; g.fillRect(0, 0, 512, 200);
    const speedMax = Math.ceil((spec.vmax * 3.6) / 20) * 20, tachMax = Math.ceil(spec.rpmMax / 1000);
    const dial = (cx, max, step, label, red) => {
      const cy = 100, r = 88;
      g.strokeStyle = '#1d2a3c'; g.lineWidth = 3; g.beginPath(); g.arc(cx, cy, r, 0, 6.283); g.stroke();
      g.font = '600 13px Arial'; g.textAlign = 'center'; g.textBaseline = 'middle';
      for (let v = 0; v <= max; v += step / 2) {
        const t = v / max, a = 0.75 * Math.PI + t * 1.5 * Math.PI, major = v % step === 0;
        const r0 = r - (major ? 16 : 9), hot = red && t > red;
        g.strokeStyle = hot ? '#ff3b3b' : '#9ee9ff'; g.lineWidth = major ? 3 : 1.5;
        g.beginPath(); g.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0); g.lineTo(cx + Math.cos(a) * (r - 3), cy + Math.sin(a) * (r - 3)); g.stroke();
        if (major) { g.fillStyle = hot ? '#ff6b6b' : '#d8f6ff'; g.fillText(String(label ? Math.round(v / label) : v), cx + Math.cos(a) * (r - 30), cy + Math.sin(a) * (r - 30)); }
      }
    };
    dial(110, tachMax * 1000, 1000, 1000, 0.85);
    dial(402, speedMax, speedMax > 200 ? 40 : 20, 0, 0);
    g.fillStyle = '#6f8aa6'; g.font = '11px Arial'; g.fillText('x1000 RPM', 110, 148); g.fillText('KM/H', 402, 148);
    return { bg: c, speedMax, tachMax };
  }

  const box = (w, h, d, mat, x, y, z, parent, shadow = false) => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
    m.position.set(x, y, z); m.castShadow = shadow; parent.add(m); return m;
  };

  /** Attach an interior to `car`. opts.simple = cheap parked-car interior (no live gauges). */
  G.buildCockpit = function (car, opts = {}) {
    if (car.cockpit) { car.body.remove(car.cockpit.group); }
    const spec = car.spec, look = car.look, [rb, rr, fr, fb] = look.cab, W = spec.W, gw = W * 0.86;
    const group = new THREE.Group();
    const dark = new THREE.MeshStandardMaterial({ color: 0x15171c, roughness: 0.75, metalness: 0.05 });
    const leather = new THREE.MeshStandardMaterial({ color: 0x1b1612, roughness: 0.55, metalness: 0.05 });
    const trim = new THREE.MeshStandardMaterial({ color: 0x2b2f38, roughness: 0.35, metalness: 0.7 });
    const cloth = new THREE.MeshStandardMaterial({ color: 0x23262d, roughness: 0.95 });

    const dashTop = fb[1] - 0.03, dashBackZ = fb[0] - 0.4, dx = 0.36;
    const wheelZ = dashBackZ - 0.12, wheelY = dashTop - 0.2;
    const eye = new THREE.Vector3(dx, look.eyeY, wheelZ - 0.52);

    // dashboard shelf, face, cowl and console
    box(W - 0.16, 0.34, 0.4, dark, 0, dashTop - 0.17, fb[0] - 0.2, group);
    box(W - 0.2, 0.3, 0.06, dark, 0, dashTop - 0.4, dashBackZ + 0.03, group);
    box(0.6, 0.05, 0.28, trim, dx, dashTop + 0.025, dashBackZ + 0.12, group); // instrument hood
    box(0.24, 0.28, 1.1, dark, 0, look.yb + 0.45, dashBackZ - 0.45, group);
    box(W - 0.3, 0.02, spec.L - 1.6, dark, 0, look.yb + 0.21, (rb[0] + fb[0]) / 2, group); // floor
    // door cards
    [-1, 1].forEach((s) => {
      box(0.06, 0.52, fb[0] - rb[0] - 0.1, dark, s * (W / 2 - 0.08), fb[1] - 0.35, (rb[0] + fb[0]) / 2, group);
      box(0.1, 0.06, 0.6, leather, s * (W / 2 - 0.13), fb[1] - 0.2, (fb[0] + rb[0]) / 2 + 0.2, group);
    });
    // seats
    const seat = (x, z) => {
      box(0.5, 0.13, 0.55, leather, x, look.yb + 0.35, z, group);
      const back = box(0.5, 0.6, 0.12, leather, x, look.yb + 0.72, z - 0.28, group); back.rotation.x = -0.18;
      box(0.2, 0.2, 0.1, leather, x, look.yb + 1.12, z - 0.33, group);
    };
    seat(dx, eye.z - 0.25); seat(-dx, eye.z - 0.25);
    box(1.4, 0.13, 0.5, cloth, 0, look.yb + 0.35, Math.max(rb[0] + 0.55, eye.z - 1.15), group);
    box(1.4, 0.55, 0.12, cloth, 0, look.yb + 0.7, Math.max(rb[0] + 0.3, eye.z - 1.4), group);

    // roof lining, A / B pillar trim
    const dy = fr[1] - rr[1], dz = fr[0] - rr[0], hl = box(gw - 0.08, 0.025, Math.hypot(dy, dz), cloth, 0, (fr[1] + rr[1]) / 2 - 0.045, (fr[0] + rr[0]) / 2, group);
    hl.rotation.x = -Math.atan2(dy, dz);
    const strut = (a, b, w) => {
      const dir = new THREE.Vector3().subVectors(b, a), m = new THREE.Mesh(new THREE.BoxGeometry(w, dir.length(), 0.09), dark);
      m.position.copy(a).addScaledVector(dir, 0.5); m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.normalize()); group.add(m); return m;
    };
    [-1, 1].forEach((s) => {
      const ex = s * (gw / 2 - 0.04);
      strut(new THREE.Vector3(ex, fb[1], fb[0] - 0.02), new THREE.Vector3(ex * 0.97, fr[1] - 0.04, fr[0] - 0.02), 0.09); // A-pillar
      strut(new THREE.Vector3(ex, fb[1], (fb[0] + rb[0]) / 2 - 0.1), new THREE.Vector3(ex, (fr[1] + rr[1]) / 2 - 0.05, (fb[0] + rb[0]) / 2 - 0.1), 0.07); // B-pillar
    });
    const t = 0.85, mz = fb[0] + (fr[0] - fb[0]) * t, my = fb[1] + (fr[1] - fb[1]) * t;
    box(0.26, 0.07, 0.04, dark, 0.05, my - 0.03, mz - 0.1, group); // rear-view mirror

    // steering wheel (rim + spokes + hub), pivot tilted toward the driver
    const wheel = new THREE.Group(), spin = new THREE.Group();
    wheel.position.set(dx, wheelY, wheelZ); wheel.rotation.x = 0.4;
    const rim = new THREE.Mesh(new THREE.TorusGeometry(0.185, 0.018, 12, 36), leather); spin.add(rim);
    for (let k = 0; k < 3; k++) { const sp = box(0.025, 0.17, 0.012, trim, 0, 0, 0, spin); sp.rotation.z = (k / 3) * Math.PI * 2 + Math.PI / 2; sp.position.set(Math.cos(sp.rotation.z - Math.PI / 2) * 0.085, Math.sin(sp.rotation.z - Math.PI / 2) * 0.085, 0); }
    const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.055, 0.04, 16).rotateX(Math.PI / 2), trim); spin.add(hub);
    wheel.add(spin); group.add(wheel);
    box(0.06, 0.06, 0.3, dark, dx, wheelY - 0.04, wheelZ + 0.15, group); // column

    // gauge cluster + infotainment
    let gaugeCtx = null, gaugeTex = null, dials = null, screenMat;
    const faceYaw = (m, from) => { const d = new THREE.Vector3().subVectors(eye, from); m.rotation.order = 'YXZ'; m.rotation.y = Math.atan2(d.x, d.z); m.rotation.x = -Math.atan2(d.y, Math.hypot(d.x, d.z)); };
    if (!opts.simple) {
      dials = dialBackground(spec);
      const { c, g } = P.canvas(512, 200); gaugeCtx = g; gaugeTex = new THREE.CanvasTexture(c); gaugeTex.colorSpace = THREE.SRGBColorSpace;
      const cluster = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.195), new THREE.MeshBasicMaterial({ map: gaugeTex, toneMapped: false }));
      cluster.position.set(dx, dashTop + 0.0, dashBackZ - 0.01); faceYaw(cluster, cluster.position); group.add(cluster);
      const sc = P.canvas(256, 128); sc.g.fillStyle = '#06121c'; sc.g.fillRect(0, 0, 256, 128);
      sc.g.strokeStyle = '#25efff'; sc.g.lineWidth = 2; for (let i = 0; i < 9; i++) { sc.g.beginPath(); sc.g.moveTo(Math.random() * 256, 0); sc.g.lineTo(Math.random() * 256, 128); sc.g.stroke(); }
      sc.g.fillStyle = '#ff3bd2'; sc.g.beginPath(); sc.g.arc(128, 64, 7, 0, 6.3); sc.g.fill(); sc.g.fillStyle = '#fff'; sc.g.font = '16px Arial'; sc.g.fillText('NEON CITY', 10, 20);
      screenMat = new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(sc.c), toneMapped: false });
      screenMat.map.colorSpace = THREE.SRGBColorSpace;
      const screen = new THREE.Mesh(new THREE.PlaneGeometry(0.3, 0.15), screenMat);
      screen.position.set(0, dashTop - 0.05, dashBackZ - 0.012); faceYaw(screen, screen.position); group.add(screen);
    }

    group.traverse((o) => { if (o.isMesh) o.castShadow = false; });
    car.body.add(group);

    let acc = 0;
    const ck = {
      group, eye, wheel: spin,
      /** s: {steer rad, speed m/s, rpm 0..1, gear, head, left, right} */
      update(s, dt) {
        spin.rotation.z = THREE.MathUtils.lerp(spin.rotation.z, s.steer * 6.5, Math.min(1, dt * 18));
        if (!gaugeCtx) return;
        acc += dt; if (acc < 1 / 30) return; acc = 0;
        const g = gaugeCtx;
        g.drawImage(dials.bg, 0, 0);
        const needle = (cx, t, col) => {
          const a = 0.75 * Math.PI + U.clamp(t, 0, 1.02) * 1.5 * Math.PI;
          g.strokeStyle = col; g.lineWidth = 4; g.shadowColor = col; g.shadowBlur = 10;
          g.beginPath(); g.moveTo(cx - Math.cos(a) * 12, 100 - Math.sin(a) * 12); g.lineTo(cx + Math.cos(a) * 76, 100 + Math.sin(a) * 76); g.stroke(); g.shadowBlur = 0;
        };
        needle(110, s.rpm * spec.rpmMax / (dials.tachMax * 1000), '#ff5a3c');
        needle(402, (s.speed * 3.6) / dials.speedMax, '#25efff');
        g.fillStyle = '#ffc84a'; g.font = '800 54px Arial'; g.textAlign = 'center'; g.textBaseline = 'middle';
        g.fillText(s.gear < 0 ? 'R' : s.gear === 0 ? 'N' : String(s.gear), 256, 78);
        g.fillStyle = '#d8f6ff'; g.font = '700 26px Arial'; g.fillText(String(Math.round(Math.abs(s.speed) * 3.6)), 256, 124);
        g.fillStyle = '#6f8aa6'; g.font = '11px Arial'; g.fillText('km/h', 256, 146);
        g.fillStyle = s.left ? '#55ff9b' : '#1b2a24'; g.fillText('\u25C0', 214, 22); g.fillStyle = s.right ? '#55ff9b' : '#1b2a24'; g.fillText('\u25B6', 298, 22);
        g.fillStyle = s.head ? '#4aa3ff' : '#1a2230'; g.fillText('\u25D0', 256, 22);
        g.fillStyle = '#10161f'; g.fillRect(206, 170, 100, 6); g.fillStyle = '#25efff'; g.fillRect(206, 170, 100 * 0.72, 6);
        gaugeTex.needsUpdate = true;
      },
    };
    car.cockpit = ck;
    return ck;
  };
})(window.Game);
