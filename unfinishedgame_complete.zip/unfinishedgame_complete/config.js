/* Constants, vehicle roster and road-grid helpers. */
(function (G) {
  'use strict';
  const C = (G.C = { PITCH: 80, ROAD: 16, GRID: 9, SIDEWALK: 6, CURB: 0.12 });
  C.BLOCK = C.PITCH - C.ROAD;
  C.HALF = (C.GRID * C.PITCH) / 2; // 360
  C.BAY_Z = C.HALF + 50; // water starts here (south)
  C.lines = Array.from({ length: C.GRID + 1 }, (_, i) => -C.HALF + i * C.PITCH); // road centre lines
  C.centers = Array.from({ length: C.GRID }, (_, i) => (i - (C.GRID - 1) / 2) * C.PITCH); // block centres

  /** Distance to the nearest road centre line along one axis. */
  C.lineDist = (a) => {
    const m = (((a + C.HALF) % C.PITCH) + C.PITCH) % C.PITCH;
    return Math.min(m, C.PITCH - m);
  };
  C.nearestLine = (a) => -C.HALF + Math.round((a + C.HALF) / C.PITCH) * C.PITCH;
  C.onRoad = (x, z) => C.lineDist(x) < C.ROAD / 2 || C.lineDist(z) < C.ROAD / 2;
  C.inCity = (x, z) => Math.abs(x) < C.HALF + C.ROAD / 2 && Math.abs(z) < C.HALF + C.ROAD / 2;
  /** Height of the walkable surface (curbs are slightly raised). */
  C.groundY = (x, z) => (C.inCity(x, z) && !C.onRoad(x, z) ? C.CURB : 0);

  /**
   * Vehicle roster. vmax m/s, accel m/s^2 (at standstill), brake m/s^2,
   * steer = max wheel angle (rad), grip = lateral velocity decay (1/s).
   */
  G.CARS = [
    { id: 'sports', name: 'Vortex GT', tag: 'Mid-engine sports coupe', L: 4.45, W: 1.92, wb: 2.65, track: 1.62, wr: 0.34,
      vmax: 74, accel: 11.5, brake: 15, steer: 0.5, grip: 7.8, mass: 1350, gears: 7, rpmMax: 8600, idle: 900, roll: 0.5 },
    { id: 'muscle', name: 'Bruiser V8', tag: 'Rear-drive muscle coupe', L: 4.9, W: 1.96, wb: 2.85, track: 1.66, wr: 0.36,
      vmax: 66, accel: 10, brake: 12.5, steer: 0.48, grip: 5.2, mass: 1750, gears: 6, rpmMax: 6800, idle: 750, roll: 0.9 },
    { id: 'sedan', name: 'Meridian S', tag: 'Executive sedan', L: 4.7, W: 1.84, wb: 2.78, track: 1.56, wr: 0.33,
      vmax: 54, accel: 6.8, brake: 11, steer: 0.55, grip: 6.6, mass: 1550, gears: 6, rpmMax: 6500, idle: 800, roll: 0.8 },
    { id: 'suv', name: 'Titan X', tag: 'Full-size luxury SUV', L: 4.85, W: 1.98, wb: 2.92, track: 1.68, wr: 0.4,
      vmax: 49, accel: 6.2, brake: 10.5, steer: 0.5, grip: 5.6, mass: 2200, gears: 6, rpmMax: 6200, idle: 780, roll: 1.35 },
  ];
  G.carById = (id) => G.CARS.find((c) => c.id === id) || G.CARS[0];

  G.PAINT = ['#d7263d', '#0a8caf', '#f4c20d', '#1d1f26', '#e9edf2', '#3ddc84', '#8e44ff', '#ff7a1a'];
  G.NEON = [0x25efff, 0xff3bd2, 0xffc84a, 0x55ff9b, 0xff5a3c, 0x8a6bff];

  /** Shared mutable game state. */
  G.state = { mode: 'menu', quality: 'high', tod: 'night' };
})(window.Game);
