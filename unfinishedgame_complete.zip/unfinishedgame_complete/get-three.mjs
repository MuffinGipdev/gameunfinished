// One-time helper: fetches three@0.159.0 and copies build/three.min.js into vendor/.
// Needs Node + npm + tar (standard on Win10+/macOS/Linux). The game itself needs no network.
import { execSync } from 'node:child_process';
import { mkdirSync, copyFileSync, rmSync } from 'node:fs';
const run = (c) => execSync(c, { stdio: 'inherit' });
rmSync('.tmp-three', { recursive: true, force: true });
mkdirSync('.tmp-three');
run('npm pack three@0.159.0 --pack-destination .tmp-three');
run('tar -xzf .tmp-three/three-0.159.0.tgz -C .tmp-three package/build/three.min.js');
mkdirSync('vendor', { recursive: true });
copyFileSync('.tmp-three/package/build/three.min.js', 'vendor/three.min.js');
rmSync('.tmp-three', { recursive: true, force: true });
console.log('vendor/three.min.js ready - open index.html');
