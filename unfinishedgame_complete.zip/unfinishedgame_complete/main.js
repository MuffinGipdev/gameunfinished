/* Runtime, input, vehicle dynamics, camera, menus and HUD. Classic-script build. */
(function(G){
'use strict';
const U=G.util,C=G.C;
const $=s=>document.querySelector(s);
function node(tag,id,cls,parent=document.body){const e=document.createElement(tag);if(id)e.id=id;if(cls)e.className=cls;parent.appendChild(e);return e;}
function buildUI(){
 const root=$('#ui');if(root)return root;
 const ui=node('div','ui');
 ui.innerHTML=`
 <section id="menu" class="layer"><div><div class="lbl">NEON DISTRICT • OPEN CITY DRIVE</div><h1>NEON CITY</h1><div class="sub">A living city after dark</div>
 <div class="cars" id="cars"></div><div class="row" id="paint"></div>
 <button class="btn go" id="start">START DRIVING →</button></div>
 <div class="keys"><b>WASD</b><span>Drive / walk</span><b>SPACE</b><span>Handbrake</span><b>E</b><span>Enter / exit vehicle</span><b>C</b><span>Change camera</span><b>L</b><span>Headlights</span><b>Q / R</b><span>Indicators</span><b>H</b><span>Horn</span><b>ESC</b><span>Pause</span></div></section>
 <section id="hud" class="layer hidden"><div class="panel tl"><div id="mode">DRIVING</div><div class="lbl" id="location">DOWNTOWN • NIGHT</div></div>
 <div class="panel" id="speedo"><div><span id="spd">000</span><small>KM/H</small></div><div id="rpmbar"><em id="rpmfill"></em></div><div><span id="gear">1</span><span class="lbl"> GEAR</span></div><div id="lamps"><span id="lamp-head">HEAD</span><span id="lamp-left">◀</span><span id="lamp-right">▶</span></div></div>
 <canvas id="minimap" width="256" height="256"></canvas><div id="prompt" class="panel hidden"></div></section>
 <section id="pause" class="layer hidden"><div><h2>PAUSED</h2><p>Press ESC to resume</p><button class="btn" id="resume">RESUME</button></div></section>
 <section id="loading" class="layer"><div><h2>BUILDING THE CITY</h2><div class="lbl">Generating streets, architecture and traffic</div><div class="bar"><em id="loadbar"></em></div></div></section>`;
 const cards=$('#cars');
 G.CARS.forEach((s,i)=>{const b=node('button',null,'card'+(i===0?' on':''),cards);b.innerHTML=`<b>${s.name}</b><small>${s.tag}</small><div class="stat"><span>POWER</span><i><em style="width:${s.accel/12*100}%"></em></i></div><div class="stat"><span>TOP SPEED</span><i><em style="width:${s.vmax/80*100}%"></em></i></div>`;b.onclick=()=>{G.state.car=i;cards.querySelectorAll('.card').forEach(x=>x.classList.remove('on'));b.classList.add('on');};});
 G.PAINT.forEach((c,i)=>{const b=node('button',null,'sw'+(i===0?' on':''),$('#paint'));b.style.background=c;b.title='Paint';b.onclick=()=>{G.state.paint=c;$('#paint').querySelectorAll('.sw').forEach(x=>x.classList.remove('on'));b.classList.add('on');if(G.player)G.player.car.setColor(c);};});
 $('#start').onclick=()=>G.start();$('#resume').onclick=()=>G.resume();
 return ui;
}
const input={keys:{},pressed:{},mouse:false};
window.addEventListener('keydown',e=>{if(!input.keys[e.code])input.pressed[e.code]=true;input.keys[e.code]=true;if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code))e.preventDefault();if(e.code==='Escape'&&G.state.mode!=='menu')G.state.paused?G.resume():G.pause();});
window.addEventListener('keyup',e=>input.keys[e.code]=false);
const down=k=>!!input.keys[k], tap=k=>{const v=!!input.pressed[k];delete input.pressed[k];return v;};
window.addEventListener('blur',()=>{input.keys={};});
G.start=function(){if(G.state.mode==='menu'){G.state.mode='playing';$('#menu').classList.add('hidden');$('#hud').classList.remove('hidden');G.Audio.init();G.player.driving=true;G.player.car.root.visible=true;}};
G.pause=()=>{G.state.paused=true;$('#pause').classList.remove('hidden');};
G.resume=()=>{G.state.paused=false;$('#pause').classList.add('hidden');};
function boot(){
 buildUI();
 const viewport=node('div','viewport');viewport.style.cssText='position:fixed;inset:0;z-index:0';document.body.insertBefore(viewport,$('#ui'));
 const fatal=node('div','fatal','');fatal.id='fatal';fatal.hidden=true;
 const scene=new THREE.Scene();scene.background=new THREE.Color(0x080d19);scene.fog=new THREE.FogExp2(0x101827,.0028);
 const camera=new THREE.PerspectiveCamera(68,innerWidth/innerHeight,.1,1400);camera.position.set(0,5,-10);
 const renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance'});
 renderer.setPixelRatio(Math.min(devicePixelRatio,1.75));renderer.setSize(innerWidth,innerHeight);
 renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
 renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1;
 if(THREE.SRGBColorSpace!==undefined)renderer.outputColorSpace=THREE.SRGBColorSpace;
 viewport.appendChild(renderer.domElement);
 const loading=v=>{$('#loadbar').style.width=(v*100)+'%';};
 try{
  loading(.08);G.Tex.build(renderer);loading(.22);
  const world=G.createWorld(scene,renderer,camera);loading(.42);
  const city=G.buildCity(scene);loading(.62);
  const spec=G.CARS[G.state.car||0],car=G.buildCar(spec,{color:G.state.paint||G.PAINT[0]});
  G.buildCockpit(car);car.root.position.set(0,0,C.lines[4]+3);car.root.rotation.y=0;scene.add(car.root);
  G.player={car,driving:true,x:0,z:C.lines[4]+3,yaw:0,speed:0,steer:0,head:1,left:false,right:false,gear:1,onFoot:null};
  car.enableSpots(true);
  G.Peds.build(scene,54);G.Traffic.build(scene,22);
  const ambient=new THREE.AudioListener();camera.add(ambient);
  loading(.88);
  const clock=new THREE.Clock();let camMode=0,footYaw=0,footSpeed=0,stepTimer=0,accel=0;
  const v3=new THREE.Vector3(),target=new THREE.Vector3(),desired=new THREE.Vector3(),forward=new THREE.Vector3();
  function setPrompt(text){const p=$('#prompt');p.innerHTML=text;p.classList.toggle('hidden',!text);}
  function toggleVehicle(){
   const p=G.player;
   if(p.driving){
    const side=new THREE.Vector3(1,0,0).applyAxisAngle(new THREE.Vector3(0,1,0),p.car.root.rotation.y);
    p.x=p.car.root.position.x+side.x*2.0;p.z=p.car.root.position.z+side.z*2.0;p.yaw=p.car.root.rotation.y;
    p.driving=false;p.car.root.visible=true;p.onFoot=new THREE.Group();scene.add(p.onFoot);
    makeWalker(p.onFoot);p.onFoot.position.set(p.x,0,p.z);p.onFoot.rotation.y=p.yaw;
    p.car.enableSpots(false);G.Audio.door();
   }else{
    if(Math.hypot(p.x-p.car.root.position.x,p.z-p.car.root.position.z)>4)return;
    p.driving=true;scene.remove(p.onFoot);p.onFoot=null;p.speed=0;p.car.enableSpots(true);G.Audio.door();
   }
  }
  function makeWalker(root){
   const skin=new THREE.MeshStandardMaterial({color:0xc99473}),cloth=new THREE.MeshStandardMaterial({color:0x273c50}),pants=new THREE.MeshStandardMaterial({color:0x202733});
   const add=(geo,m,x,y,z,sx=1,sy=1,sz=1)=>{const o=new THREE.Mesh(geo,m);o.position.set(x,y,z);o.scale.set(sx,sy,sz);o.castShadow=true;root.add(o);return o;};
   add(new THREE.CapsuleGeometry(.24,.52,5,10),cloth,0,1.05,0);
   add(new THREE.SphereGeometry(.17,16,12),skin,0,1.72,0);
   const legs=[];[-1,1].forEach(s=>{const pivot=new THREE.Group();pivot.position.set(s*.12,.78,0);root.add(pivot);const l=add(new THREE.CapsuleGeometry(.085,.42,4,8),pants,0,-.25,0);pivot.add(l);legs.push(pivot);});
   root.userData.legs=legs;
  }
  function updateDriving(dt){
   const p=G.player,c=p.car,s=c.spec;
   const throttle=(down('KeyW')||down('ArrowUp')?1:0)-(down('KeyS')||down('ArrowDown')?1:0);
   const steer=(down('KeyD')||down('ArrowRight')?1:0)-(down('KeyA')||down('ArrowLeft')?1:0);
   const hand=down('Space');
   const maxForward=s.vmax, maxReverse=11;
   const targetAccel=throttle>0?s.accel:throttle<0?(p.speed>1?-s.brake:-s.accel*.48):0;
   p.speed+=targetAccel*dt;
   if(!throttle)p.speed*=Math.exp(-(s.roll*.45+.34)*dt);
   if(hand)p.speed*=Math.exp(-4.8*dt);
   p.speed=U.clamp(p.speed,-maxReverse,maxForward);
   p.steer=U.damp(p.steer,steer*s.steer,9,dt);
   const speedFactor=U.clamp(Math.abs(p.speed)/5,0,1);
   c.root.rotation.y+=p.steer*(p.speed>=0?1:-1)*speedFactor*dt*(1.25+Math.abs(p.speed)*.055);
   const yaw=c.root.rotation.y;forward.set(Math.sin(yaw),0,Math.cos(yaw));
   c.root.position.addScaledVector(forward,p.speed*dt);
   const col=G.Collide.resolve(c.root.position.x,c.root.position.z,Math.max(s.W,s.L)*.36);
   if(col.hit){c.root.position.x=col.x;c.root.position.z=col.z;p.speed*=.58;if(Math.abs(p.speed)>5)G.Audio.crash(Math.abs(p.speed));}
   // Keep the car inside the drivable city and animate wheel steering/rotation.
   c.wheels.forEach(w=>{if(w.front)w.pivot.rotation.y=U.damp(w.pivot.rotation.y,p.steer*1.35,12,dt);w.spin.rotation.x+=p.speed*dt/s.wr;});
   const rpm=U.clamp(.18+Math.abs(p.speed)/s.vmax*.72+Math.abs(throttle)*.1,0,1);
   const gear=p.speed<-.5?-1:Math.max(1,Math.min(s.gears,Math.floor(Math.abs(p.speed)/12)+1));
   c.setLights({head:p.head,brake:throttle<0&&p.speed>1,reverse:p.speed<-.5,left:p.left,right:p.right},dt);
   c.cockpit.update({steer:p.steer,speed:p.speed,rpm,gear,head:p.head,left:p.left,right:p.right},dt);
   G.Audio.update({rpm,load:Math.abs(throttle),speed:Math.abs(p.speed),slip:hand?0.6:0,driving:true},dt);
   $('#spd').textContent=String(Math.round(Math.abs(p.speed)*3.6)).padStart(3,'0');$('#rpmfill').style.width=(rpm*100)+'%';$('#gear').textContent=gear<0?'R':gear;
   $('#lamp-head').classList.toggle('on',p.head>0);$('#lamp-left').classList.toggle('on',p.left);$('#lamp-right').classList.toggle('on',p.right);
   if(tap('KeyL')){p.head=(p.head+1)%3;c.enableSpots(p.head>0);}
   if(tap('KeyQ')){p.left=!p.left;p.right=false;}if(tap('KeyR')){p.right=!p.right;p.left=false;}
   if(down('KeyH'))G.Audio.horn(true);else G.Audio.horn(false);
   if(tap('KeyC'))camMode=(camMode+1)%2;
  }
  function updateFoot(dt){
   const p=G.player;
   const f=(down('KeyW')||down('ArrowUp')?1:0)-(down('KeyS')||down('ArrowDown')?1:0);
   const side=(down('KeyD')||down('ArrowRight')?1:0)-(down('KeyA')||down('ArrowLeft')?1:0);
   const moving=Math.hypot(f,side)>.01;
   if(moving){const desiredYaw=Math.atan2(side,f)+p.yaw;p.yaw+=U.angleDiff(p.yaw,desiredYaw)*Math.min(1,dt*8);}
   footSpeed=U.damp(footSpeed,moving?3.2:0,8,dt);
   const dir=new THREE.Vector3(Math.sin(p.yaw),0,Math.cos(p.yaw));
   p.x+=dir.x*footSpeed*dt;p.z+=dir.z*footSpeed*dt;
   const hit=G.Collide.resolve(p.x,p.z,.32);p.x=hit.x;p.z=hit.z;
   p.onFoot.position.set(p.x,0,p.z);p.onFoot.rotation.y=p.yaw;
   const phase=performance.now()*.009*footSpeed;p.onFoot.userData.legs.forEach((l,i)=>l.rotation.x=Math.sin(phase+i*Math.PI)*.55);
   if(moving&&performance.now()>stepTimer){G.Audio.step(false);stepTimer=performance.now()+390;}
   $('#spd').textContent=String(Math.round(footSpeed*3.6)).padStart(3,'0');$('#gear').textContent='WALK';$('#rpmfill').style.width=(footSpeed/4*100)+'%';
   G.Audio.update({rpm:0,load:0,speed:footSpeed,slip:0,driving:false},dt);
   if(tap('KeyC'))camMode=(camMode+1)%2;
  }
  function cameraUpdate(dt){
   const p=G.player;
   if(p.driving){
    if(camMode===1){
     const eye=p.car.cockpit.eye.clone();p.car.body.localToWorld(eye);
     camera.position.copy(eye);camera.rotation.order='YXZ';camera.rotation.set(0,p.car.root.rotation.y,0);
     camera.fov=68;
    }else{
     const yaw=p.car.root.rotation.y,sp=p.speed;
     desired.set(-Math.sin(yaw)*8,4.0+Math.min(1,Math.abs(sp)/35)*1.2,-Math.cos(yaw)*8);
     target.copy(p.car.root.position).add(new THREE.Vector3(0,1,0));
     desired.add(target);camera.position.lerp(desired,1-Math.exp(-4.5*dt));camera.lookAt(target);camera.fov=U.damp(camera.fov,68-Math.min(8,Math.abs(sp)*.12),3,dt);
    }
   }else{
    target.set(p.x,1.45,p.z);desired.set(p.x-Math.sin(p.yaw)*5,3.0,p.z-Math.cos(p.yaw)*5);
    camera.position.lerp(desired,1-Math.exp(-5*dt));camera.lookAt(target);camera.fov=68;
   }
   camera.updateProjectionMatrix();
  }
  function minimap(){
   const ctx=$('#minimap').getContext('2d'),m=city.minimap;if(!m)return;
   ctx.clearRect(0,0,256,256);ctx.drawImage(m.canvas,0,0,256,256);
   const p=G.player,x=(p.driving?p.car.root.position.x:p.x),z=(p.driving?p.car.root.position.z:p.z);
   const px=(x+m.ext)*m.k/4,pz=(z+m.ext)*m.k/4;
   ctx.save();ctx.translate(px,pz);ctx.rotate(-(p.driving?p.car.root.rotation.y:p.yaw));ctx.fillStyle='#25efff';ctx.beginPath();ctx.moveTo(0,-8);ctx.lineTo(5,6);ctx.lineTo(0,3);ctx.lineTo(-5,6);ctx.closePath();ctx.fill();ctx.restore();
  }
  function frame(){
   requestAnimationFrame(frame);const dt=Math.min(clock.getDelta(),.04);
   if(G.state.mode==='playing'&&!G.state.paused){
    if(tap('KeyE'))toggleVehicle();
    if(G.player.driving)updateDriving(dt);else updateFoot(dt);
    const p=G.player;const focus=p.driving?p.car.root.position:new THREE.Vector3(p.x,0,p.z);
    G.Peds.update(dt);G.Traffic.update(dt,p);world.update(dt,focus);cameraUpdate(dt);
    const near=Math.hypot(p.x-(p.car.root.position.x),p.z-p.car.root.position.z);
    setPrompt(!p.driving&&near<5?'<b>E</b> ENTER VEHICLE':p.driving?'<b>E</b> EXIT VEHICLE':'');
    minimap();
   }else if(G.state.mode==='menu'){world.update(dt,new THREE.Vector3());camera.position.x=Math.sin(performance.now()*.00008)*2;camera.lookAt(0,2,0);}
   renderer.render(scene,camera);
  }
  frame();loading(1);setTimeout(()=>$('#loading').classList.add('hidden'),350);
  addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);});
 }catch(err){console.error(err);$('#loading').innerHTML='<div><h2>Unable TO START</h2><p>Check that three.min.js is beside index.html and is version 0.159.0.</p><pre>'+String(err)+'</pre></div>';}
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>{if(!window.THREE||!THREE.WebGLRenderer){const f=node('div','fatal');f.innerHTML='<h2>Three.js library missing</h2><p>Place three.min.js beside index.html. This project intentionally does not download it.</p>';return;}boot();});else{if(window.THREE&&THREE.WebGLRenderer)boot();}
})(window.Game);
