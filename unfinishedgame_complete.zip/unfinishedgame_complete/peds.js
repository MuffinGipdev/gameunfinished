/* Articulated sidewalk pedestrians with deterministic routes and joint-driven gait. */
(function (G) {
  'use strict';
  const U = G.util;
  const mat = (c, r=.82) => new THREE.MeshStandardMaterial({color:c, roughness:r});
  const skin = [0xc88f70,0xe0b18d,0x96664f,0xf0c7a2].map(c=>mat(c));
  const shirts = [0x34546a,0x8a493f,0x586b48,0x66527e,0xb28a45,0x343b48].map(c=>mat(c));
  const pants = [0x202a37,0x3e4148,0x4b4a40,0x263c43].map(c=>mat(c));
  const sphere = new THREE.SphereGeometry(1,14,10);
  const limbGeo = new THREE.CapsuleGeometry(.075,.34,4,8);
  function makePerson(i) {
    const root=new THREE.Group(), rig=new THREE.Group(); root.add(rig);
    const shirt=shirts[i%shirts.length], trou=pants[(i*3)%pants.length], face=skin[i%skin.length];
    const add=(geo,m,p,s,parent=rig)=>{const o=new THREE.Mesh(geo,m);o.position.set(...p);if(s)o.scale.set(...s);o.castShadow=true;o.receiveShadow=true;parent.add(o);return o;};
    add(new THREE.CapsuleGeometry(.22,.43,5,10),shirt,[0,1.12,0],[1,1,0.62]);
    add(sphere,face,[0,1.79,0],[.16,.2,.16]);
    add(new THREE.CylinderGeometry(.075,.09,.13,10),shirt,[0,1.53,0]);
    // Hair cap and small facial features
    add(new THREE.SphereGeometry(.165,12,8,0,Math.PI*2,0,Math.PI*.48),mat([0x29211e,0x44332a,0x17191e][i%3]),[0,1.86,-.012],[1,1,1]);
    const eyeMat=mat(0x17191d,.5);
    [-1,1].forEach(s=>add(sphere,eyeMat,[s*.055,1.8,.142],[.018,.025,.012]));
    const armPivots=[], legPivots=[];
    [-1,1].forEach(s=>{
      const a=new THREE.Group();a.position.set(s*.25,1.39,0);rig.add(a);armPivots.push(a);
      add(limbGeo,shirt,[0,-.2,0],null,a);
      const hand=add(sphere,face,[0,-.43,.01],[.065,.07,.065],a);
      const l=new THREE.Group();l.position.set(s*.115,.82,0);rig.add(l);legPivots.push(l);
      add(new THREE.CapsuleGeometry(.085,.39,4,8),trou,[0,-.25,0],null,l);
      add(new THREE.BoxGeometry(.15,.09,.29),mat(0x171b22),[0,-.49,.065],null,l);
    });
    const bag=i%4===0?add(new THREE.BoxGeometry(.22,.3,.1),mat(0x282b30),[.29,1.22,-.1]):null;
    return {root,rig,armPivots,legPivots,phase:(i*.83)%6.28, speed: .75+(i%5)*.09, bag};
  }
  G.Peds={
    list:[],
    build(scene,count=48){
      this.group=new THREE.Group();scene.add(this.group);this.list=[];
      const C=G.C, rng=U.rng(451);
      for(let i=0;i<count;i++){
        const p=makePerson(i), vertical=rng()<.5, lane=U.pick(rng,[-1,1]), block=U.pick(rng,C.centers);
        p.axis=vertical?'z':'x';p.fixed=block+lane*(C.ROAD/2+C.SIDEWALK*.52);
        p.min=-C.HALF+8;p.max=C.HALF-8;p.pos=U.range(rng,p.min,p.max);
        p.dir=rng()<.5?1:-1;p.root.position.set(vertical?p.fixed: p.pos,0,vertical?p.pos:p.fixed);
        p.root.rotation.y=vertical?(p.dir>0?0:Math.PI):(p.dir>0?Math.PI/2:-Math.PI/2);
        this.group.add(p.root);this.list.push(p);
      }
      return this;
    },
    update(dt){
      for(const p of this.list){
        p.pos+=p.dir*p.speed*dt;
        if(p.pos>p.max){p.pos=p.max;p.dir=-1;}if(p.pos<p.min){p.pos=p.min;p.dir=1;}
        p.root.position[p.axis]=p.pos;
        p.root.rotation.y=p.axis==='z'?(p.dir>0?0:Math.PI):(p.dir>0?Math.PI/2:-Math.PI/2);
        p.phase+=dt*p.speed*7;
        const swing=Math.sin(p.phase)*.58;
        p.armPivots[0].rotation.x=swing;p.armPivots[1].rotation.x=-swing;
        p.legPivots[0].rotation.x=-swing;p.legPivots[1].rotation.x=swing;
        p.rig.position.y=Math.abs(Math.sin(p.phase*2))*.025;
      }
    }
  };
})(window.Game);
