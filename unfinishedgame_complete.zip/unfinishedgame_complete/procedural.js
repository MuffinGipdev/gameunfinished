/* Low-level procedural image tools (no external files, no network). */
(function (G) {
  'use strict';
  const P = (G.proc = {});

  P.canvas = (w, h) => {
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    return { c, g: c.getContext('2d') };
  };

  /** Tileable fractal value noise: returns f(u,v)->[0,1] for u,v in [0,1). */
  P.fbm = (rand, octaves = 5, base = 4) => {
    const lat = [];
    for (let o = 0; o < octaves; o++) {
      const f = base << o, a = new Float32Array(f * f);
      for (let i = 0; i < a.length; i++) a[i] = rand();
      lat.push({ f, a });
    }
    return (u, v) => {
      let sum = 0, amp = 1, tot = 0;
      for (const { f, a } of lat) {
        const x = u * f, y = v * f, xi = Math.floor(x), yi = Math.floor(y);
        const fx = x - xi, fy = y - yi, sx = fx * fx * (3 - 2 * fx), sy = fy * fy * (3 - 2 * fy);
        const x0 = xi % f, x1 = (xi + 1) % f, y0 = yi % f, y1 = (yi + 1) % f;
        const a00 = a[y0 * f + x0], a10 = a[y0 * f + x1], a01 = a[y1 * f + x0], a11 = a[y1 * f + x1];
        const top = a00 + (a10 - a00) * sx, bot = a01 + (a11 - a01) * sx;
        sum += amp * (top + (bot - top) * sy);
        tot += amp; amp *= 0.5;
      }
      return sum / tot;
    };
  };

  /** Fill a canvas per pixel. fn(u,v,x,y) -> [r,g,b] in 0..255 (alpha optional 4th). */
  P.fill = (w, h, fn) => {
    const { c, g } = P.canvas(w, h), img = g.createImageData(w, h), d = img.data;
    for (let y = 0; y < h; y++)
      for (let x = 0; x < w; x++) {
        const px = fn(x / w, y / h, x, y), i = (y * w + x) * 4;
        d[i] = px[0]; d[i + 1] = px[1]; d[i + 2] = px[2]; d[i + 3] = px[3] === undefined ? 255 : px[3];
      }
    g.putImageData(img, 0, 0);
    return c;
  };

  /** Convert a grayscale height canvas into a tangent-space normal map canvas (wraps at edges). */
  P.heightToNormal = (src, strength = 2) => {
    const w = src.width, h = src.height, sd = src.getContext('2d').getImageData(0, 0, w, h).data;
    const { c, g } = P.canvas(w, h), out = g.createImageData(w, h), d = out.data;
    const H = (x, y) => sd[(((y + h) % h) * w + ((x + w) % w)) * 4] / 255;
    for (let y = 0; y < h; y++)
      for (let x = 0; x < w; x++) {
        const dx = (H(x + 1, y) - H(x - 1, y)) * strength, dy = (H(x, y + 1) - H(x, y - 1)) * strength;
        const l = Math.hypot(dx, dy, 1), i = (y * w + x) * 4;
        d[i] = ((-dx / l) * 0.5 + 0.5) * 255; d[i + 1] = ((dy / l) * 0.5 + 0.5) * 255; d[i + 2] = (1 / l) * 255 * 0.5 + 127.5; d[i + 3] = 255;
      }
    g.putImageData(out, 0, 0);
    return c;
  };

  P.rgb = (v) => [v, v, v];
})(window.Game);
