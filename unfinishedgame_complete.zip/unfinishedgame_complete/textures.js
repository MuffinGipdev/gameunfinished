/* All textures are painted at runtime onto canvases. Roughness maps use the G channel (grayscale). */
(function (G) {
  'use strict';
  const P = G.proc, U = G.util;
  let aniso = 4;

  function tex(canvas, srgb, wrap = true) {
    const t = new THREE.CanvasTexture(canvas);
    if (wrap) t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.anisotropy = aniso;
    if (srgb) t.colorSpace = THREE.SRGBColorSpace;
    return t;
  }
  const gray = (v) => Math.max(0, Math.min(255, v * 255));

  /** 512px tile = 16 m of road: wheel tracks, grit, cracks, oil, patches and wet puddles. */
  function asphalt() {
    const S = 512, rand = U.rng(7), low = P.fbm(rand, 6, 4), mid = P.fbm(rand, 4, 16), pud = P.fbm(rand, 3, 3);
    const R = new Float32Array(S * S), Hh = new Float32Array(S * S);
    const albedo = P.fill(S, S, (u, v, x, y) => {
      const l = low(u, v), m = mid(u, v), grit = rand();
      const lane = (u * 2) % 1;
      const track = Math.exp(-Math.pow((lane - 0.3) * 13, 2)) + Math.exp(-Math.pow((lane - 0.7) * 13, 2));
      const puddle = U.smoothstep(0.585, 0.64, pud(u, v) * 0.85 + m * 0.15);
      const oil = U.smoothstep(0.78, 0.9, m) * 0.6;
      let g = 0.21 + 0.11 * l + 0.05 * (grit - 0.5) + (grit > 0.94 ? 0.1 : 0) - 0.035 * track;
      g *= 1 - 0.38 * puddle - 0.25 * oil;
      const i = y * S + x;
      R[i] = Math.max(0.05, 0.86 - 0.16 * track + 0.08 * (grit - 0.5) - 0.8 * puddle - 0.45 * oil);
      Hh[i] = (0.35 * l + 0.4 * grit + 0.25 * m) * (1 - 0.8 * puddle);
      return [gray(g * 0.98), gray(g), gray(g * 1.05)];
    });
    // cracks & patches painted into albedo and height
    const cg = albedo.getContext('2d'), hc = P.fill(S, S, (u, v, x, y) => P.rgb(gray(Hh[y * S + x])));
    const hg = hc.getContext('2d');
    for (let k = 0; k < 14; k++) {
      let x = rand() * S, y = rand() * S, a = rand() * 6.28;
      cg.strokeStyle = 'rgba(8,8,10,0.75)'; hg.strokeStyle = 'rgba(0,0,0,0.9)'; cg.lineWidth = hg.lineWidth = 0.8 + rand();
      cg.beginPath(); hg.beginPath(); cg.moveTo(x, y); hg.moveTo(x, y);
      for (let s = 0; s < 22; s++) { a += (rand() - 0.5) * 1.1; x += Math.cos(a) * 9; y += Math.sin(a) * 9; cg.lineTo(x, y); hg.lineTo(x, y); }
      cg.stroke(); hg.stroke();
    }
    for (let k = 0; k < 4; k++) { // repaired patches
      const x = rand() * (S - 120), y = rand() * (S - 120), w = 50 + rand() * 70, h = 40 + rand() * 60;
      cg.fillStyle = 'rgba(10,10,12,0.22)'; cg.fillRect(x, y, w, h);
      hg.fillStyle = 'rgba(70,70,70,0.25)'; hg.fillRect(x, y, w, h);
    }
    const rough = P.fill(S, S, (u, v, x, y) => P.rgb(gray(R[y * S + x])));
    return { map: tex(albedo, true), rough: tex(rough, false), normal: tex(P.heightToNormal(hc, 2.6), false) };
  }

  /** Paving slabs with joints and stains. */
  function sidewalk() {
    const S = 256, rand = U.rng(21), n = P.fbm(rand, 5, 4);
    const Hh = new Float32Array(S * S);
    const albedo = P.fill(S, S, (u, v, x, y) => {
      const jx = x % 64, jy = y % 64, joint = jx < 2 || jy < 2 ? 1 : 0;
      const slab = ((Math.floor(x / 64) * 7 + Math.floor(y / 64) * 13) % 5) / 5;
      const g = 0.42 + 0.14 * n(u, v) + 0.03 * slab + 0.04 * (rand() - 0.5) - 0.2 * joint;
      Hh[y * S + x] = 0.7 - 0.55 * joint + 0.15 * n(u, v);
      return [gray(g), gray(g * 0.99), gray(g * 0.96)];
    });
    const hc = P.fill(S, S, (u, v, x, y) => P.rgb(gray(Hh[y * S + x])));
    const rough = P.fill(S, S, (u, v) => P.rgb(gray(0.78 + 0.2 * n(u, v))));
    return { map: tex(albedo, true), rough: tex(rough, false), normal: tex(P.heightToNormal(hc, 3), false) };
  }

  /** Building facade tile: 4 window columns x 4 floors (12 m x 14.4 m). Albedo, roughness, lit-window emissive. */
  function facade() {
    const W = 256, H = 512, rand = U.rng(99);
    const a = P.canvas(W, H), r = P.canvas(W, H), e = P.canvas(W, H);
    a.g.fillStyle = '#74777e'; a.g.fillRect(0, 0, W, H);
    r.g.fillStyle = '#e4e4e4'; r.g.fillRect(0, 0, W, H);
    e.g.fillStyle = '#000'; e.g.fillRect(0, 0, W, H);
    for (let i = 0; i < 5000; i++) { // concrete speckle + streaks
      const x = rand() * W, y = rand() * H, v = 100 + rand() * 50;
      a.g.fillStyle = `rgba(${v},${v},${v + 4},0.2)`; a.g.fillRect(x, y, 1 + rand() * 2, 1 + rand() * 6);
    }
    const warm = ['#ffd9a0', '#ffe9c8', '#ffcf8a', '#bfe3ff', '#ffb3e6'];
    for (let fy = 0; fy < 4; fy++)
      for (let fx = 0; fx < 4; fx++) {
        const x = fx * 64 + 9, y = fy * 128 + 22, w = 46, h = 84;
        a.g.fillStyle = '#1c232e'; a.g.fillRect(x - 3, y - 3, w + 6, h + 6); // frame
        const gr = a.g.createLinearGradient(x, y, x + w, y + h);
        gr.addColorStop(0, '#223349'); gr.addColorStop(0.5, '#0f1722'); gr.addColorStop(1, '#1b2b40');
        a.g.fillStyle = gr; a.g.fillRect(x, y, w, h);
        a.g.fillStyle = 'rgba(160,200,255,0.16)'; // reflection streak
        a.g.beginPath(); a.g.moveTo(x + 4, y + h); a.g.lineTo(x + 20, y); a.g.lineTo(x + 32, y); a.g.lineTo(x + 16, y + h); a.g.fill();
        a.g.fillStyle = '#2a303b'; a.g.fillRect(x + w / 2 - 1, y, 2, h); a.g.fillRect(x, y + h * 0.42, w, 2); // mullions
        a.g.fillStyle = '#9a9ca3'; a.g.fillRect(x - 5, y + h + 3, w + 10, 4); // sill
        r.g.fillStyle = '#e8e8e8'; r.g.fillRect(x - 3, y - 3, w + 6, h + 6);
        r.g.fillStyle = '#1e1e1e'; r.g.fillRect(x, y, w, h); // glass is glossy
        if (rand() < 0.4) {
          const c = U.pick(rand, warm), eg = e.g.createLinearGradient(x, y, x, y + h);
          eg.addColorStop(0, c); eg.addColorStop(1, '#3a2a18');
          e.g.fillStyle = eg; e.g.fillRect(x, y + (rand() < 0.3 ? 20 : 0), w, h);
        }
      }
    return { map: tex(a.c, true), rough: tex(r.c, false), emissive: tex(e.c, true) };
  }

  function glow() {
    const { c, g } = P.canvas(128, 128), gr = g.createRadialGradient(64, 64, 0, 64, 64, 64);
    gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.25, 'rgba(255,255,255,0.35)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
    return tex(c, true, false);
  }

  function hex(c) { return '#' + c.toString(16).padStart(6, '0'); }
  const signCache = new Map();
  /** Neon sign texture, cached per text+colour. */
  function sign(text, color, w = 512, h = 160) {
    const k = text + color;
    if (signCache.has(k)) return signCache.get(k);
    const { c, g } = P.canvas(w, h);
    g.fillStyle = '#05060a'; g.fillRect(0, 0, w, h);
    g.strokeStyle = hex(color); g.lineWidth = 6; g.shadowColor = hex(color); g.shadowBlur = 22;
    g.strokeRect(14, 14, w - 28, h - 28);
    g.font = '800 ' + Math.floor(h * 0.5) + 'px "Segoe UI",Arial,sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillStyle = '#fff'; g.fillText(text, w / 2, h / 2 + 4); g.shadowBlur = 8; g.fillStyle = hex(color); g.fillText(text, w / 2, h / 2 + 4);
    const t = tex(c, true, false);
    signCache.set(k, t);
    return t;
  }

  function plate(text) {
    const { c, g } = P.canvas(128, 64);
    g.fillStyle = '#eef0f2'; g.fillRect(0, 0, 128, 64); g.strokeStyle = '#223'; g.lineWidth = 3; g.strokeRect(3, 3, 122, 58);
    g.fillStyle = '#12203a'; g.font = 'bold 34px monospace'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(text, 64, 34);
    return tex(c, true, false);
  }

  /** Subtle noise for ground outside the city / plaza stone. */
  function ground() {
    const rand = U.rng(5), n = P.fbm(rand, 5, 8);
    const albedo = P.fill(256, 256, (u, v) => { const g = 0.12 + 0.1 * n(u, v); return [gray(g), gray(g * 1.04), gray(g * 0.95)]; });
    return tex(albedo, true);
  }

  /** Tiling water normal map used by the water shader. */
  function waterNormal() {
    const rand = U.rng(33), n = P.fbm(rand, 5, 4), S = 256;
    const hc = P.fill(S, S, (u, v) => P.rgb(gray(n(u, v))));
    return tex(P.heightToNormal(hc, 5), false);
  }

  G.Tex = {
    sign, plate, hex,
    build(renderer) {
      aniso = Math.min(8, renderer.capabilities.getMaxAnisotropy());
      return (G.tex = { asphalt: asphalt(), sidewalk: sidewalk(), facade: facade(), glow: glow(), ground: ground(), waterN: waterNormal() });
    },
  };
})(window.Game);
