/* Lane-following ambient traffic and a deterministic enter/exit interaction. */
(function(G){
'use strict';
const U=G.util,C=G.C;
G.Traffic={
 cars:[], scene:null,
 build(scene,count=18){
  this.scene=scene;this.cars=[];
  const rng=U.rng(817), specs=G.CARS;
  for(let i=0;i<count;i++){
   const vertical=rng()<.5, lane=U.pick(rng,[-1,1]), line=U.pick(rng,C.lines);
   const spec=specs[(i+1)%specs.length], car=G.buildCar(spec,{color:G.PAINT[(i+2)%G.PAINT.length],plate:'CITY'});
   car.root.scale.setScalar(.88);car.root.position.set(vertical?line+lane*3.1:U.range(rng,-C.HALF,C.HALF),0,vertical?U.range(rng,-C.HALF,C.HALF):line+lane*3.1);
   const dir=rng()<.5?1:-1, along=vertical?'z':'x';
   car.root.rotation.y=vertical?(dir>0?0:Math.PI):(dir>0?Math.PI/2:-Math.PI/2);
   scene.add(car.root);
   this.cars.push({car,vertical,lane,line,dir,along,speed:U.range(rng,5,10),phase:rng()*30});
  }
  return this;
 },
 update(dt,player){
  for(const t of this.cars){
   const r=t.car.root;r.position[t.along]+=t.dir*t.speed*dt;
   if(r.position[t.along]>C.HALF+20)r.position[t.along]=-C.HALF-20;
   if(r.position[t.along]<-C.HALF-20)r.position[t.along]=C.HALF+20;
   // Yield gently if a player vehicle is directly ahead in the same corridor.
   if(player&&player.driving){
    const dx=r.position.x-player.car.root.position.x,dz=r.position.z-player.car.root.position.z;
    if(dx*dx+dz*dz<55&&Math.abs(U.angleDiff(r.rotation.y,player.car.root.rotation.y))<.55)r.position[t.along]-=t.dir*dt*2.2;
   }
   t.car.wheels.forEach(w=>{w.spin.rotation.x+=t.dir*t.speed*dt/(t.car.spec.wr||.34);});
   t.car.setLights({head:1,brake:false,reverse:false,left:false,right:false},dt);
  }
 }
};
})(window.Game);
