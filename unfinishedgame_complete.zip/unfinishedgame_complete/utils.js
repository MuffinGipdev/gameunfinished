/* Shared helpers. Loaded first; only touches THREE inside functions. */
window.Game = window.Game || {};
(function (G) {
  'use strict';
  const U = (G.util = {});
  const TAU = Math.PI * 2;

  U.clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  U.lerp = (a, b, t) => a + (b - a) * t;
  U.damp = (a, b, k, dt) => a + (b - a) * (1 - Math.exp(-k * dt));
  U.smooth = (t) => t * t * (3 - 2 * t);
  U.smoothstep = (a, b, x) => U.smooth(U.clamp((x - a) / (b - a), 0, 1));
  U.angleDiff = (a, b) => {
    let d = (b - a) % TAU;
    if (d > Math.PI) d -= TAU;
    if (d < -Math.PI) d += TAU;
    return d;
  };
  U.pick = (r, arr) => arr[Math.floor(r() * arr.length)];
  U.range = (r, a, b) => a + (b - a) * r();

  /** Seeded PRNG (mulberry32). */
  U.rng = (seed) => {
    let s = seed >>> 0;
    return () => {
      s = (s + 0x6d2b79f5) >>> 0;
      let t = s;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  };

  /** Chaikin corner cutting on a [[x,y],...] polygon. */
  U.chaikin = (pts, iters) => {
    for (let k = 0; k < iters; k++) {
      const out = [];
      for (let i = 0; i < pts.length; i++) {
        const a = pts[i], b = pts[(i + 1) % pts.length];
        out.push([0.75 * a[0] + 0.25 * b[0], 0.75 * a[1] + 0.25 * b[1]]);
        out.push([0.25 * a[0] + 0.75 * b[0], 0.25 * a[1] + 0.75 * b[1]]);
      }
      pts = out;
    }
    return pts;
  };

  /** Average normals of coincident vertices whose faces are within `deg` of each other. */
  U.smoothNormals = (geo, deg) => {
    const p = geo.attributes.position, n = geo.attributes.normal, cnt = p.count;
    const cos = Math.cos((deg * Math.PI) / 180), map = new Map();
    for (let i = 0; i < cnt; i++) {
      const k = Math.round(p.getX(i) * 400) + ',' + Math.round(p.getY(i) * 400) + ',' + Math.round(p.getZ(i) * 400);
      const l = map.get(k);
      if (l) l.push(i); else map.set(k, [i]);
    }
    const out = new Float32Array(cnt * 3);
    for (const list of map.values()) {
      for (const i of list) {
        const nx = n.getX(i), ny = n.getY(i), nz = n.getZ(i);
        let x = 0, y = 0, z = 0;
        for (const j of list) {
          const mx = n.getX(j), my = n.getY(j), mz = n.getZ(j);
          if (nx * mx + ny * my + nz * mz > cos) { x += mx; y += my; z += mz; }
        }
        const l = Math.hypot(x, y, z) || 1;
        out[i * 3] = x / l; out[i * 3 + 1] = y / l; out[i * 3 + 2] = z / l;
      }
    }
    geo.setAttribute('normal', new THREE.BufferAttribute(out, 3));
    return geo;
  };

  /** Merge [{g: BufferGeometry, m?: Matrix4, c?: Color}] into one non-indexed geometry with vertex colours. */
  U.merge = (items) => {
    let total = 0;
    const list = items.map((it) => {
      let g = it.g.index ? it.g.toNonIndexed() : it.m ? it.g.clone() : it.g;
      if (it.m) g.applyMatrix4(it.m);
      total += g.attributes.position.count;
      return { g, c: it.c };
    });
    const pos = new Float32Array(total * 3), nor = new Float32Array(total * 3);
    const uv = new Float32Array(total * 2), col = new Float32Array(total * 3).fill(1);
    let o = 0;
    for (const { g, c } of list) {
      const n = g.attributes.position.count;
      pos.set(g.attributes.position.array, o * 3);
      nor.set(g.attributes.normal.array, o * 3);
      if (g.attributes.uv) uv.set(g.attributes.uv.array, o * 2);
      if (g.attributes.color) col.set(g.attributes.color.array, o * 3);
      else if (c) for (let i = 0; i < n; i++) { col[(o + i) * 3] = c.r; col[(o + i) * 3 + 1] = c.g; col[(o + i) * 3 + 2] = c.b; }
      o += n;
    }
    const out = new THREE.BufferGeometry();
    out.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    out.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
    out.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
    out.setAttribute('color', new THREE.BufferAttribute(col, 3));
    return out;
  };

  /** Matrix from position / y-rotation / scale. */
  const _o = {};
  U.mat = (x, y, z, ry = 0, sx = 1, sy = 1, sz = 1) => {
    const o = _o.o || (_o.o = new THREE.Object3D());
    o.position.set(x, y, z); o.rotation.set(0, ry, 0); o.scale.set(sx, sy, sz); o.updateMatrix();
    return o.matrix.clone();
  };

  /** Registry of PBR materials that react to the environment map / time of day. */
  G.envMats = [];
  G.reg = (m, k = 1) => { m.userData.envK = k; G.envMats.push(m); if (G.env) m.envMap = G.env; return m; };
})(window.Game);
