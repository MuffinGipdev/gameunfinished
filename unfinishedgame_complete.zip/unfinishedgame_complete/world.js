/* Atmosphere & lighting: sky dome, stars, sun/moon with cascaded-style following shadows,
 * PMREM environment, animated reflective water shader, time of day and a pooled set of point lights. */
(function (G) {
  'use strict';
  const U = G.util, C = G.C;

  const SKY_VS = 'varying vec3 vD; void main(){ vD = normalize(position); gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.); }';
  const SKY_FS = `uniform vec3 top; uniform vec3 hor; uniform vec3 sunDir; uniform vec3 sunCol; varying vec3 vD;
    void main(){ vec3 d = normalize(vD); float h = d.y;
      vec3 c = mix(hor, top, pow(clamp(h,0.,1.),0.5));
      c = mix(c, hor*0.35, clamp(-h*6.,0.,1.));
      float s = max(dot(d, sunDir), 0.);
      c += sunCol*(pow(s,1400.)*6. + pow(s,10.)*0.18);
      gl_FragColor = vec4(c,1.);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
    }`;

  const WATER_VS = `varying vec3 vW;
    #include <fog_pars_vertex>
    void main(){ vec4 wp = modelMatrix*vec4(position,1.); vW = wp.xyz;
      vec4 mvPosition = viewMatrix*wp; gl_Position = projectionMatrix*mvPosition;
      #include <fog_vertex>
    }`;
  const WATER_FS = `uniform float time; uniform float night; uniform vec3 top; uniform vec3 hor; uniform vec3 sunDir; uniform vec3 sunCol; uniform sampler2D nrm;
    varying vec3 vW;
    #include <common>
    #include <fog_pars_fragment>
    float hash(vec2 p){ return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453); }
    vec2 waves(vec2 p, float t){ vec2 g = vec2(0.);
      for(int i=0;i<5;i++){ float fi = float(i); vec2 d = vec2(cos(fi*1.9+.4), sin(fi*1.9+.4));
        float f = 0.28 + fi*0.5; float a = 0.1/(1.+fi*0.8); float ph = dot(d,p)*f + t*(0.7+fi*0.3);
        g += d*cos(ph)*a*f; } return g; }
    void main(){
      vec2 p = vW.xz;
      vec2 g = waves(p, time);
      vec3 n1 = texture2D(nrm, p*0.045 + vec2(time*0.012, time*0.008)).xyz*2.-1.;
      vec3 n2 = texture2D(nrm, p*0.12 - vec2(time*0.02, -time*0.015)).xyz*2.-1.;
      vec3 N = normalize(vec3(-g.x + (n1.x+n2.x)*0.2, 1., -g.y + (n1.y+n2.y)*0.2));
      vec3 V = normalize(cameraPosition - vW);
      vec3 R = reflect(-V, N); R.y = max(R.y, 0.02);
      float fres = mix(0.05, 1., pow(1. - max(dot(N,V),0.), 4.));
      vec3 refl = mix(hor, top, pow(clamp(R.y,0.,1.),0.5));
      refl += sunCol*pow(max(dot(normalize(R), sunDir),0.), 260.)*7.;
      // neon skyline reflected in the ripples
      float ang = atan(R.z, R.x)*16.; vec2 cell = vec2(floor(ang), 0.);
      float lit = step(0.74, hash(cell+3.)) * (0.6 + 0.4*sin(time*2.5 + hash(cell)*20.));
      vec3 pal = mix(vec3(.1,.9,1.), vec3(1.,.2,.8), step(.5, hash(cell))); pal = mix(pal, vec3(1.,.75,.25), step(.85, hash(cell+7.)));
      vec3 city = pal*lit*smoothstep(0.55, 0., R.y)*night*2.2;
      vec3 deep = vec3(0.012,0.05,0.07) + hor*0.04;
      vec3 col = mix(deep, refl + city, fres);
      col += pow(max(0., n1.x*n2.y), 3.)*0.25*(0.3+night); // sparkle
      gl_FragColor = vec4(col, 1.);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
      #include <fog_fragment>
    }`;

  // key frames for time of day: 0 = night, 0.5 = dusk, 1 = day
  const KEY = [
    { top: 0x02050f, hor: 0x16264a, fog: 0x0a1226, fogD: 0.0062, sun: 0x8fa9e8, sunI: 2.3, el: 38, hemiS: 0x31457a, hemiG: 0x0f0c18, hemiI: 1.5, exp: 1.05, night: 1, env: 0.55 },
    { top: 0x26346a, hor: 0xe5707a, fog: 0x7d4f6b, fogD: 0.0042, sun: 0xffb372, sunI: 7, el: 11, hemiS: 0x7676b8, hemiG: 0x2e1d2b, hemiI: 2, exp: 0.95, night: 0.4, env: 0.9 },
    { top: 0x3f7fd6, hor: 0xc4dcf0, fog: 0xa9c8e4, fogD: 0.0026, sun: 0xfff1d6, sunI: 11, el: 52, hemiS: 0xbcd8ff, hemiG: 0x4a463e, hemiI: 2.6, exp: 0.8, night: 0, env: 1.0 },
  ];
  const TOD = { night: 0, dusk: 0.5, day: 1 };

  G.createWorld = function (scene, renderer, camera) {
    const tex = G.tex, col = (h) => new THREE.Color(h);
    const world = { k: { night: 1, lamp: 1, win: 1 }, tod: 0, todTarget: 0, time: 0 };

    // ---- sky ----
    const skyU = { top: { value: col(0) }, hor: { value: col(0) }, sunDir: { value: new THREE.Vector3(0, 1, 0) }, sunCol: { value: col(0xffffff) }, night: { value: 1 } };
    const sky = new THREE.Mesh(new THREE.SphereGeometry(900, 32, 16), new THREE.ShaderMaterial({ uniforms: skyU, vertexShader: SKY_VS, fragmentShader: SKY_FS, side: THREE.BackSide, depthWrite: false, fog: false }));
    sky.renderOrder = -10; sky.frustumCulled = false; scene.add(sky);
    const sp = new Float32Array(1200 * 3), r = U.rng(3);
    for (let i = 0; i < 1200; i++) { const a = r() * 6.283, e = Math.asin(r() * 0.97 + 0.03), R = 860; sp[i * 3] = Math.cos(a) * Math.cos(e) * R; sp[i * 3 + 1] = Math.sin(e) * R; sp[i * 3 + 2] = Math.sin(a) * Math.cos(e) * R; }
    const sg = new THREE.BufferGeometry(); sg.setAttribute('position', new THREE.BufferAttribute(sp, 3));
    const stars = new THREE.Points(sg, new THREE.PointsMaterial({ color: 0xffffff, size: 1.7, sizeAttenuation: false, transparent: true, depthWrite: false, fog: false }));
    stars.frustumCulled = false; scene.add(stars);

    // ---- lights ----
    const hemi = new THREE.HemisphereLight(0x31457a, 0x0f0c18, 1.5); scene.add(hemi);
    const sun = new THREE.DirectionalLight(0xffffff, 2); sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    const sc = sun.shadow.camera; sc.left = sc.bottom = -75; sc.right = sc.top = 75; sc.near = 1; sc.far = 420;
    sun.shadow.bias = -0.0004; sun.shadow.normalBias = 0.05;
    scene.add(sun, sun.target);
    scene.fog = new THREE.FogExp2(0x0a1226, 0.006);
    world.sun = sun; world.hemi = hemi;

    // ---- environment (PMREM from a procedural neon skyline) ----
    {
      const es = new THREE.Scene(), eu = { top: { value: col(0x101c3c) }, hor: { value: col(0x8a4a7c) }, sunDir: { value: new THREE.Vector3(0.3, 0.2, -0.9).normalize() }, sunCol: { value: col(0xffb070) } };
      es.add(new THREE.Mesh(new THREE.SphereGeometry(500, 24, 12), new THREE.ShaderMaterial({ uniforms: eu, vertexShader: SKY_VS, fragmentShader: SKY_FS, side: THREE.BackSide, depthWrite: false })));
      const rr = U.rng(11), pal = [0x25efff, 0xff3bd2, 0xffc84a];
      for (let i = 0; i < 28; i++) {
        const a = (i / 28) * 6.283 + rr() * 0.2, c = col(pal[i % 3]).multiplyScalar(3 + rr() * 3);
        const b = new THREE.Mesh(new THREE.BoxGeometry(24 + rr() * 30, 10 + rr() * 50, 4), new THREE.MeshBasicMaterial({ color: c }));
        b.position.set(Math.cos(a) * 220, 8 + rr() * 20, Math.sin(a) * 220); b.lookAt(0, 8, 0); es.add(b);
      }
      const pm = new THREE.PMREMGenerator(renderer);
      G.env = pm.fromScene(es, 0.02, 0.1, 1000).texture; pm.dispose();
      scene.environment = G.env;
      G.envMats.forEach((m) => (m.envMap = G.env));
    }

    // ---- ground + animated reflective water ----
    tex.ground.repeat.set(260, 260);
    const gmat = new THREE.MeshStandardMaterial({ map: tex.ground, roughness: 0.96, metalness: 0 });
    const gh = 2000 + C.BAY_Z, ground = new THREE.Mesh(new THREE.PlaneGeometry(4000, gh).rotateX(-Math.PI / 2), gmat);
    ground.position.set(0, -0.01, (C.BAY_Z - 2000) / 2); ground.receiveShadow = true; scene.add(ground);

    const wu = THREE.UniformsUtils.clone(THREE.UniformsLib.fog);
    Object.assign(wu, { time: { value: 0 }, nrm: { value: tex.waterN }, top: skyU.top, hor: skyU.hor, sunDir: skyU.sunDir, sunCol: skyU.sunCol, night: skyU.night });
    const wmat = (G.waterMat = new THREE.ShaderMaterial({ uniforms: wu, vertexShader: WATER_VS, fragmentShader: WATER_FS, fog: true }));
    const bay = new THREE.Mesh(new THREE.PlaneGeometry(4000, 2000).rotateX(-Math.PI / 2), wmat);
    bay.position.set(0, -0.8, C.BAY_Z + 1000); scene.add(bay);
    const quay = new THREE.Mesh(new THREE.BoxGeometry(4000, 1, 2), new THREE.MeshStandardMaterial({ color: 0x2b2d33, roughness: 0.9 }));
    quay.position.set(0, -0.3, C.BAY_Z); quay.castShadow = quay.receiveShadow = true; scene.add(quay);

    // ---- pooled point lights for nearby neon signs / lamps ----
    const POOL = 8, pool = [];
    for (let i = 0; i < POOL; i++) { const l = new THREE.PointLight(0xffffff, 0, 34, 2); scene.add(l); pool.push({ l, src: null, k: 0, base: 0 }); }
    let poolT = 0;
    world.updatePool = (dt, focus) => {
      const sources = G.sources || [];
      poolT -= dt;
      if (poolT <= 0 && sources.length) {
        poolT = 0.25;
        const best = [];
        for (const s of sources) {
          const dx = s.x - focus.x, dz = s.z - focus.z, d = dx * dx + dz * dz;
          if (d > 2500) continue;
          if (best.length < POOL || d < best[best.length - 1].d) {
            best.push({ s, d }); best.sort((a, b) => a.d - b.d); if (best.length > POOL) best.pop();
          }
        }
        const want = best.map((b) => b.s), free = pool.filter((p) => !want.includes(p.src));
        for (const s of want) if (!pool.some((p) => p.src === s) && free.length) free.shift().want = s;
      }
      for (const p of pool) {
        if (p.want && p.want !== p.src) { p.k -= dt * 7; if (p.k <= 0) { p.src = p.want; p.want = null; p.k = 0; const s = p.src; p.l.position.set(s.x, s.y, s.z); p.l.color.setHex(s.color); p.base = s.i; } }
        else p.k = Math.min(1, p.k + dt * 7);
        p.l.intensity = p.src ? p.base * p.k * world.k.lamp : 0;
      }
    };

    // ---- time of day ----
    const tmpC = new THREE.Color();
    function lerpKey(a, b, t) {
      const L = (k) => U.lerp(a[k], b[k], t);
      skyU.top.value.copy(col(a.top)).lerp(tmpC.copy(col(b.top)), t);
      skyU.hor.value.copy(col(a.hor)).lerp(tmpC.copy(col(b.hor)), t);
      scene.fog.color.copy(col(a.fog)).lerp(tmpC.copy(col(b.fog)), t); scene.fog.density = L('fogD');
      sun.color.copy(col(a.sun)).lerp(tmpC.copy(col(b.sun)), t); sun.intensity = L('sunI');
      skyU.sunCol.value.copy(sun.color);
      hemi.color.copy(col(a.hemiS)).lerp(tmpC.copy(col(b.hemiS)), t);
      hemi.groundColor.copy(col(a.hemiG)).lerp(tmpC.copy(col(b.hemiG)), t); hemi.intensity = L('hemiI');
      renderer.toneMappingExposure = L('exp');
      const night = L('night'); skyU.night.value = night; world.k.night = night; world.k.lamp = U.clamp(night * 1.4, 0, 1); world.k.win = night;
      stars.material.opacity = U.clamp((night - 0.35) * 1.6, 0, 1); stars.visible = stars.material.opacity > 0.01;
      world.el = L('el');
      const env = L('env');
      for (const m of G.envMats) m.envMapIntensity = env * (m.userData.envK || 1);
    }
    world.setTod = (name, instant) => { world.todTarget = TOD[name] === undefined ? 0 : TOD[name]; if (instant) { world.tod = world.todTarget; world.applyTod(); } };
    world.applyTod = () => { const x = world.tod; if (x <= 0.5) lerpKey(KEY[0], KEY[1], x / 0.5); else lerpKey(KEY[1], KEY[2], (x - 0.5) / 0.5); };

    const sd = new THREE.Vector3(), snap = new THREE.Vector3();
    world.update = (dt, focus) => {
      world.time += dt; wu.time.value = world.time;
      if (Math.abs(world.tod - world.todTarget) > 0.0005) { world.tod += Math.sign(world.todTarget - world.tod) * Math.min(Math.abs(world.todTarget - world.tod), dt * 0.35); world.applyTod(); }
      const el = (world.el * Math.PI) / 180, az = 2.2;
      sd.set(Math.cos(el) * Math.sin(az), Math.sin(el), Math.cos(el) * Math.cos(az));
      skyU.sunDir.value.copy(sd);
      snap.set(Math.round(focus.x), 0, Math.round(focus.z));
      sun.target.position.copy(snap); sun.position.copy(snap).addScaledVector(sd, 200);
      sky.position.copy(camera.position); stars.position.copy(camera.position);
      world.updatePool(dt, focus);
    };
    world.setTod(G.state.tod, true);
    return world;
  };
})(window.Game);
